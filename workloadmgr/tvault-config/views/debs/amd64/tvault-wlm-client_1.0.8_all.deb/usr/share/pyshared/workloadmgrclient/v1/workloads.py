# Copyright (c) 2014 TrilioData, Inc.
# All Rights Reserved.

"""
Workloads Interface (1.1 extension).
"""
from workloadmgrclient import base


class Workload(base.Resource):
    """A workload describes a grouping of one or more VMs"""
    def __repr__(self):
        return "<Workload: %s>" % self.id

    def delete(self):
        """Delete this workload."""
        return self.manager.delete(self)

    def snapshot(self, full, name=None, description=None):
        """Snapshot the workload full or incremental """
        return self.manager.snapshot(self, full, name, description)
    
    def pause(self):
        """Pause the workload"""
        return self.manager.pause(self)
    
    def resume(self):
        """Resume the workload"""
        return self.manager.resume(self)      
    
    def unlock(self):
        """Unlock the workload"""
        return self.manager.unlock(self)     
    
    def update(self, workload_id, name, description, workload_type_id, instances, jobschedule, metadata):
        """Update the workload"""
        return self.manager.update(workload_id, name, description, workload_type_id, instances, jobschedule, metadata)     


class WorkloadsManager(base.ManagerWithFind):
    """Manage :class:`Workload` resources."""
    resource_class = Workload

    def create(self, name, description, workload_type_id, instances, jobschedule, metadata):
        """Create a workload.

        :param instances: List of instances to be included in the workload.
        :param workload_type_id: Type of the workload
        :param name: The name of the workload.
        :param description: The description of the workload.
        :rtype: :class:`Workload`
        """
        body = {'workload': {   'name': name,
                                'description': description,
                                'workload_type_id': workload_type_id,
                                'instances': instances,
                                'jobschedule': jobschedule,
                                'metadata' : metadata}}
        return self._create('/workloads', body, 'workload')

    def get(self, workload_id):
        """Show details of a workload.

        :param workload_id: The ID of the workload to display.
        :rtype: :class:`Workload`
        """
        return self._get("/workloads/%s" % workload_id, "workload")

    def list(self, detailed=True):
        """Get a list of all workloads.

        :rtype: list of :class:`Workload`
        """
        if detailed is True:
            return self._list("/workloads/detail", "workloads")
        else:
            return self._list("/workloads", "workloads")

    def delete(self, workload_id):
        """Delete a workload.

        :param workload_id: The :class:`Workload` to delete.
        """
        self._delete("/workloads/%s" % base.getid(workload_id))

    def snapshot(self, workload_id, full=False, name=None, description=None):
        """Snapshots a workload.
        :param workload_id: The :class:`Workload` to snapshot.
        :param name: The name of the snapshot.
        :param description: The description of the snapshot.        
        """
        body = {'snapshot': { 'name': name, 'description': description}}        
        if full == True:
            self._snapshot("/workloads/%s?full=1" % base.getid(workload_id), body)
        else:
            self._snapshot("/workloads/%s" % base.getid(workload_id), body)

    def get_workflow(self, workload_id):
        """Get workflow details of a workload.

        :param workload_id: The ID of the workload
        :rtype: workflow
        """
        return self._get_without_id("/workloads/%s/workflow" % workload_id, "workflow")
    
    def get_topology(self, workload_id):
        """Get topology details of a workload.

        :param workload_id: The ID of the workload
        :rtype: workflow
        """
        return self._get_without_id("/workloads/%s/topology" % workload_id, "topology")
 
        
    def pause(self, workload_id):
        """
        pause a workload.
        """
        return self._pause("/workloads/%s/pause" % base.getid(workload_id))
    
    def resume(self, workload_id):
        """
        resume a workload.
        """
        return self._resume("/workloads/%s/resume" % base.getid(workload_id)) 
    
    def unlock(self, workload_id):
        """
        unlock a workload.
        """
        return self._unlock("/workloads/%s/unlock" % base.getid(workload_id))     
    
    def update(self, workload_id, name, description, workload_type_id, instances, jobschedule, metadata): 
        workload = {}
        if name:
            workload['name'] = name
        if description:
            workload['description'] = description
        if workload_type_id:
            workload['workload_type_id'] = workload_type_id
        if instances and len(instances) > 0:
            workload['instances'] = instances
        if metadata and len(metadata) > 0:
            workload['metadata'] = metadata
                                                
        body = {'workload': workload}
        return self._update('/workloads/%s' % base.getid(workload_id), body)   
