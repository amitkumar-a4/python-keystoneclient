# Copyright (c) 2014 TrilioData, Inc.
# All Rights Reserved.

__all__ = ['__version__']

import pbr.version

version_info = pbr.version.VersionInfo('python-workloadmgrclient')
# We have a circular import problem when we first run python setup.py sdist
# It's harmless, so deflect it.
try:
    #__version__ = version_info.version_string()
    __version__ = '1.0.5'
except AttributeError:
    __version__ = None
