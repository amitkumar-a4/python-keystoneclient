# Copyright (c) 2014 TrilioData, Inc.
# All Rights Reserved.

"""
Snapshots interface (1.1 extension).
"""

import six
try:
    from urllib import urlencode
except ImportError:
    from urllib.parse import urlencode
    
from workloadmgrclient import base


class Snapshot(base.Resource):
    """A workload snapshot either full or incremental"""
    def __repr__(self):
        return "<Snapshot: %s>" % self.id
    
    def delete(self):
        """Delete this snapshot."""
        return self.manager.delete(self)    

    def restore(self, test, name=None, description=None, options=None):
        """Restore the snapshot """
        return self.manager.restore(self, test, name, description, options)

class SnapshotsManager(base.ManagerWithFind):
    """Manage :class:`Snapshot` resources."""
    resource_class = Snapshot


    def get(self, snapshot_id):
        """Show details of a workload snapshot.

        :param snapshot_id: The ID of the workload snapshot to display.
        :rtype: :class:`Snapshot`
        """
        return self._get("/snapshots/%s" % snapshot_id, "snapshot")

    def list(self, detailed=True, search_opts=None):
        """Get a list of all workload snapshots.p

        :rtype: list of :class:`Snapshot`
        """
        if search_opts is None:
            search_opts = {}   
            
        qparams = {}

        for opt, val in six.iteritems(search_opts):
            if val:
                qparams[opt] = val

        query_string = "?%s" % urlencode(qparams) if qparams else ""

        detail = ""
        if detailed:
            detail = "/detail"
        
        return self._list("/snapshots%s%s" % (detail, query_string),
                          "snapshots")
                          
    def delete(self, snapshot_id):
        """Delete a workload snapshot.

        :param snapshot_id: The :class:`Snapshot` to delete.
        """
        self._delete("/snapshots/%s" % base.getid(snapshot_id))

    def restore(self, snapshot_id, test=False, name=None, description=None, options=None):
        """restores a workload snapshot.

        :param snapshot_id: The :class:`Snapshot` to restore.
        """

        if test == True:
            body = {'testbubble': { 'name': name, 'description': description, 'options':options}}
            self._restore("/snapshots/%s?test=1" % base.getid(snapshot_id), body)
        else:
            body = {'restore': { 'name': name, 'description': description, 'options':options}}
            self._restore("/snapshots/%s" % base.getid(snapshot_id), body)

