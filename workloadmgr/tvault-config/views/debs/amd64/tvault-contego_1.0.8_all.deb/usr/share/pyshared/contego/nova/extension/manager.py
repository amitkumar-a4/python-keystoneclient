# Copyright 2014 TrilioData Inc.
# All Rights Reserved.

"""
Handles all processes relating to Contego functionality

The :py:class:`ContegoManager` class is a :py:class:`nova.manager.Manager` that
handles RPC calls relating to Contego functionality creating instances.
"""

import re
import os
import socket
import fcntl
import struct
import subprocess
import time
import thread

import greenlet
from eventlet import greenthread
from eventlet.green import threading as gthreading

from nova import block_device
from nova import conductor
from nova import exception
from nova import manager
from nova import network
from nova import notifications
from nova import volume
from nova.compute import manager as compute_manager
from nova.compute import power_state
from nova.compute import task_states
from nova.compute import vm_states
# We need to import this module because other nova modules use the flags that
# it defines (without actually importing this module). So we need to ensure
# this module is loaded so that we can have access to those flags.
from nova.network import manager as network_manager
from nova.network import model as network_model
from nova.objects import instance as instance_obj
from nova.openstack.common import importutils
from nova.openstack.common import jsonutils
from nova.openstack.common import log as logging
from nova.openstack.common import periodic_task
from nova.openstack.common import rpc
from nova.openstack.common import timeutils
from nova.openstack.common.gettextutils import _
from nova.openstack.common.notifier import api as notifier
from nova.openstack.common.rpc import common as rpc_common

from oslo.config import cfg

from contego.nova.extension.driver.libvirtdriver import LibvirtDriver
import vastdata 

LOG = logging.getLogger('nova.contego.manager')
CONF = cfg.CONF

contego_opts = [
                cfg.IntOpt('contego_vast_data_listen_port',
                default=8899,
                help='port for contego vast data server to listen on'),
                ]
CONF.register_opts(contego_opts)
CONF.import_opt('contego_topic', 'contego.nova.api')
CONF.import_opt('instances_path', 'nova.compute.manager')

def _lock_call(fn):
    """
    A decorator to lock methods to ensure that mutliple operations do not occur on the same
    instance at a time. Note that this is a local lock only, so it just prevents concurrent
    operations on the same host.
    """

    def wrapped_fn(self, context, **kwargs):
        instance_uuid = kwargs.get('instance_uuid', None)
        instance_ref = kwargs.get('instance_ref', None)

        # Ensure we've got exactly one of uuid or ref.
        if instance_uuid and not(instance_ref):
            instance_ref = instance_obj.Instance.get_by_uuid(context,
                                                             instance_uuid)
            kwargs['instance_ref'] = instance_ref
            assert instance_ref is not None
        elif instance_ref and not(instance_uuid):
            instance_uuid = instance_ref['uuid']
            kwargs['instance_uuid'] = instance_ref['uuid']

        LOG.debug(_("%s called: %s"), fn.__name__, str(kwargs))
        if type(instance_ref) == dict:
            # Cover for the case where we don't have a proper object.
            instance_ref['name'] = CONF.instance_name_template % instance_ref['id']

        LOG.debug("Locking instance %s (fn:%s)" % (instance_uuid, fn.__name__))
        self._lock_instance(instance_uuid)
        try:
            return fn(self, context, **kwargs)
        finally:
            self._unlock_instance(instance_uuid)
            LOG.debug(_("Unlocked instance %s (fn: %s)" % (instance_uuid, fn.__name__)))

    wrapped_fn.__name__ = fn.__name__
    wrapped_fn.__doc__ = fn.__doc__

    return wrapped_fn

def memory_string_to_pages(mem):
    mem = mem.lower()
    units = { '^(\d+)tb$' : 40,
              '^(\d+)gb$' : 30,
              '^(\d+)mb$' : 20,
              '^(\d+)kb$' : 10,
              '^(\d+)b$' : 0,
              '^(\d+)$' : 0 }
    for (pattern, shift) in units.items():
        m = re.match(pattern, mem)
        if m is not None:
            val = long(m.group(1))
            memory = val << shift
            # Shift to obtain pages, at least one
            return max(1, memory >> 12)
    raise ValueError('Invalid target string %s.' % mem)

def _log_error(operation):
    """ Log exceptions with a common format. """
    LOG.exception(_("Error during %s") % operation)

def _retry_rpc(fn):
    def wrapped_fn(*args, **kwargs):
        timeout = CONF.contego_compute_timeout
        i = 0
        start = time.time()
        while True:
            try:
                return fn(*args, **kwargs)
            except rpc_common.Timeout:
                elapsed = time.time() - start
                if elapsed > timeout:
                    raise
                LOG.debug(_("%s timing out after %d seconds, try %d."),
                            fn.__name__, elapsed, i)
                i += 1

    wrapped_fn.__name__ = fn.__name__
    wrapped_fn.__doc__ = fn.__doc__

    return wrapped_fn

def get_interface_ip(ifname):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    return socket.inet_ntoa(fcntl.ioctl(s.fileno(), 0x8915, struct.pack('256s',
                            ifname[:15]))[20:24])
    
def get_lan_ip():
    ip = socket.gethostbyname(socket.gethostname())
    if ip.startswith("127.") and os.name != "nt":
        interfaces = [
            "eth0",
            "eth1",
            "eth2",
            "wlan0",
            "wlan1",
            "wifi0",
            "ath0",
            "ath1",
            "ppp0",
            ]
        for ifname in interfaces:
            try:
                ip = get_interface_ip(ifname)
                break
            except IOError:
                pass
    return ip

class ContegoManager(manager.SchedulerDependentManager):

    def __init__(self, *args, **kwargs):
        self.compute_manager = compute_manager.ComputeManager()
        self.conductor_api = conductor.API()
        self.driver = LibvirtDriver(self.compute_manager.driver)


        # Use an eventlet green thread condition lock instead of the regular threading module. This
        # is required for eventlet threads because they essentially run on a single system thread.
        # All of the green threads will share the same base lock, defeating the point of using the
        # it. Since the main threading module is not monkey patched we cannot use it directly.
        self.cond = gthreading.Condition()
        self.locked_instances = {}
        super(ContegoManager, self).__init__(service_name="contego", *args, **kwargs)

        #Start a new thread to serve the vast data
        thread.start_new_thread(vastdata.serve_vast_data, (CONF.contego_vast_data_listen_port,))
        

    def _lock_instance(self, instance_uuid):
        self.cond.acquire()
        try:
            LOG.debug(_("Acquiring lock for instance %s" % (instance_uuid)))
            current_thread = id(greenlet.getcurrent())

            while True:
                (locking_thread, refcount) = self.locked_instances.get(instance_uuid,
                                                                       (current_thread, 0))
                if locking_thread != current_thread:
                    LOG.debug(_("Lock for instance %s already acquired by %s (me: %s)" \
                            % (instance_uuid, locking_thread, current_thread)))
                    self.cond.wait()
                else:
                    break

            LOG.debug(_("Acquired lock for instance %s (me: %s, refcount=%s)" \
                        % (instance_uuid, current_thread, refcount + 1)))
            self.locked_instances[instance_uuid] = (locking_thread, refcount + 1)
        finally:
            self.cond.release()

    def _unlock_instance(self, instance_uuid):
        self.cond.acquire()
        try:
            if instance_uuid in self.locked_instances:
                (locking_thread, refcount) = self.locked_instances[instance_uuid]
                if refcount == 1:
                    del self.locked_instances[instance_uuid]
                    # The lock is now available for other threads to take so wake them up.
                    self.cond.notifyAll()
                else:
                    self.locked_instances[instance_uuid] = (locking_thread, refcount - 1)
        finally:
            self.cond.release()

    @_lock_call
    def vast_prepare(self, context, instance_uuid, instance_ref, params):
        """
        Prepare for the VAST
        """
        return self.driver.vast_prepare(context, instance_uuid, instance_ref, params)
    
    @_lock_call
    def vast_freeze(self, context, instance_uuid, instance_ref, params):
        """
        Freeze
        """
        return self.driver.vast_freeze(context, instance_uuid, instance_ref, params)
    
    @_lock_call
    def vast_thaw(self, context, instance_uuid, instance_ref, params):
        """
        Thaw
        """
        return self.driver.vast_thaw(context, instance_uuid, instance_ref, params)

    @_lock_call
    def vast_instance(self, context, instance_uuid, instance_ref, params):
        """
        VAST the instance
        """
        return self.driver.vast_instance(context, instance_uuid, instance_ref, params)

    @_lock_call
    def vast_get_info(self, context, instance_uuid, instance_ref, params):
        """
        Get the info(disks etc) of a VAST Snapshot
        """
        return self.driver.vast_get_info(context, instance_uuid, instance_ref, params)
    
    @_lock_call
    def vast_data_url(self, context, instance_uuid, instance_ref, params):
        """
        Get the VAST Data URL
        """
        urls = []
        urls.append('http://' + get_lan_ip() + ':' + str(CONF.contego_vast_data_listen_port) + '/vastdata')
        urls.append('http://' + socket.gethostname() + ':' + str(CONF.contego_vast_data_listen_port) + '/vastdata') 
        return {'urls' : urls}
    
    @_lock_call
    def vast_data(self, context, instance_uuid, instance_ref, params):
        """
        Upload the VAST Snapshot
        """
        return self.driver.vast_data(context, instance_uuid, instance_ref, params)
    
    @_lock_call
    def vast_finalize(self, context, instance_uuid, instance_ref, params):
        """
        Finalize the VAST Snapshot
        """
        return self.driver.vast_finalize(context, instance_uuid, instance_ref, params)
    
    @_lock_call
    def testbubble_attach_volume(self, context, instance_uuid, instance_ref, params):
        """
        Attach a volume using a file
        """
        return self.driver.testbubble_attach_volume(context, instance_uuid, instance_ref, params) 
    
    @_lock_call
    def testbubble_reboot_instance(self, context, instance_uuid, instance_ref, params):
        """
        Support simple reboot unlike nova soft and hard reboot
        """
        return self.driver.testbubble_reboot_instance(context, instance_uuid, instance_ref, params)
    
