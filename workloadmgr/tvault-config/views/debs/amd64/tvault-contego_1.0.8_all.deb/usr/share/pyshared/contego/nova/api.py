# Copyright 2014 TrilioData Inc.
# All Rights Reserved.



"""Handles all requests relating to Contego functionality."""
import sys

from nova import exception
from nova import context
from nova.db import base
from nova.objects import instance as instance_obj
from nova.openstack.common import log as logging
from nova.openstack.common import rpc
from nova.openstack.common.gettextutils import _
from oslo.config import cfg


# New API capabilities should be added here

CAPABILITIES = ['live-snapshot',
                ]

LOG = logging.getLogger('nova.contego.api')
CONF = cfg.CONF

contego_api_opts = [
               cfg.StrOpt('contego_topic',
               default='contego',
               help='the topic Contego nodes listen on') ]
CONF.register_opts(contego_api_opts)

class API(base.Base):
    """API for interacting with the contego manager."""

    # Allow passing in dummy image_service, but normally use the default
    def __init__(self, image_service=None, **kwargs):
        super(API, self).__init__(**kwargs)
        self.CAPABILITIES = CAPABILITIES

    def get_info(self):
        return {'capabilities': self.CAPABILITIES}

    def get(self, context, instance_uuid, want_object=False):
        """Get a single instance with the given instance_uuid."""
        if want_object:
            instance = instance_obj.Instance.get_by_uuid(context, instance_uuid)
            return instance

        rv = self.db.instance_get_by_uuid(context, instance_uuid)
        return dict(rv.iteritems())

    def _send_contego_message(self, method, context, instance, host=None,
                              params=None, is_call=False, timeout=60):
        """Generic handler for RPC casts/calls to contego topic.
           This only blocks for a response with is_call=True.

        :param params: Optional dictionary of arguments to be passed to the
                       contego worker

        :returns: None
        """
        if not params:
            params = {}
        if not host:
            host = instance['host']
        if not host:
            queue = CONF.contego_topic
        else:
            queue = rpc.queue_get_for(context, CONF.contego_topic, host)
        
        args = {}
        args['instance_uuid'] = instance['uuid']
        args['params'] = params        
        
        kwargs = {'method': method, 'args': args, 'timeout' : timeout}

        if is_call:
            return rpc.call(context, queue, kwargs)
        else:
            rpc.cast(context, queue, kwargs)

    def vast_prepare(self, context, instance_uuid, params):
        """
        Prepare to VAST the instance
        """
        instance = self.get(context, instance_uuid)
        LOG.debug(_("prepare to vast the instance") % locals())
        return self._send_contego_message('vast_prepare', context, instance, host=instance['host'], params=params, is_call = True)
    
    def vast_freeze(self, context, instance_uuid, params):
        """
        Freeze the instance
        """
        instance = self.get(context, instance_uuid)
        LOG.debug(_("freeze the instance") % locals())
        return self._send_contego_message('vast_freeze', context, instance, host=instance['host'], params=params, is_call = True)
    
    def vast_thaw(self, context, instance_uuid, params):
        """
        Thaw the instance
        """
        instance = self.get(context, instance_uuid)
        LOG.debug(_("thaw the instance") % locals())
        return self._send_contego_message('vast_thaw', context, instance, host=instance['host'], params=params, is_call = True)        
    
    def vast_instance(self, context, instance_uuid, params):
        """
        VAST the instance
        """
        instance = self.get(context, instance_uuid)
        LOG.debug(_("vast the instance") % locals())
        return self._send_contego_message('vast_instance', context, instance, host=instance['host'], params=params, is_call = True)        

    def vast_get_info(self, context, instance_uuid, params):
        """
        Get the details of a VASTed the instance
        """
        instance = self.get(context, instance_uuid)
        LOG.debug(_("get details of vasted instance") % locals())
        return self._send_contego_message('vast_get_info', context, instance, host=instance['host'], params=params, is_call = True)        

    def vast_data_url(self, context, instance_uuid, params):
        """
        Get the URL for the vast data server
        """
        instance = self.get(context, instance_uuid)
        LOG.debug(_("Get the URL for the vast data server") % locals())
        return self._send_contego_message('vast_data_url', context, instance, host=instance['host'], params=params, is_call = True)        

    def vast_data(self, context, instance_uuid, params):
        """
        Upload the VASTed instance component
        """
        instance = self.get(context, instance_uuid)
        LOG.debug(_("return a read iterator to the specified vasted component") % locals())
        return self._send_contego_message('vast_data', context, instance, host=instance['host'], params=params, is_call = True)        


    def vast_finalize(self, context, instance_uuid, params):
        """
        Finalize the VAST
        """
        instance = self.get(context, instance_uuid)
        LOG.debug(_("finalize the vast for the instance") % locals())
        return self._send_contego_message('vast_finalize', context, instance, host=instance['host'], params=params, is_call = True, timeout = 180)
    
    def testbubble_attach_volume(self, context, instance_uuid, params):
        """
        Attach a volume to a test bubble
        """
        instance = self.get(context, instance_uuid)
        LOG.debug(_("Attach a volume to a testbubble instance") % locals())
        return self._send_contego_message('testbubble_attach_volume', context, instance, host=instance['host'], params=params, is_call = True)
    
    def testbubble_reboot_instance(self, context, instance_uuid, params):
        """
        Reboot a test bubble
        """
        instance = self.get(context, instance_uuid)
        LOG.debug(_("reboot a testbubble instance") % locals())
        return self._send_contego_message('testbubble_reboot_instance', context, instance, host=instance['host'], params=params, is_call = True)        

    