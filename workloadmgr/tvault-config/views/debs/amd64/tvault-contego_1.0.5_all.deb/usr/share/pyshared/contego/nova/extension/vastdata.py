# Copyright 2014 TrilioData Inc.
# All Rights Reserved.
import os
import time
import bottle
from bottle import route, run, template, static_file, HTTPError
from nova import utils
from nova.openstack.common.gettextutils import _
from nova.openstack.common import log as logging
from oslo.config import cfg

LOG = logging.getLogger('nova.contego.manager')


CONF = cfg.CONF

def serve_vast_data(port):

    @route('/hello/<name>')
    def index(name):
        return template('<b>Hello {{name}}</b>!', name=name)
    
    @route('/vastdata/<filename:path>')
    def download(filename):
        root = CONF.instances_path
        root = os.path.abspath(root) + os.sep
        filename = os.path.abspath(os.path.join(root, filename.strip('/\\')))
        if not filename.startswith(root):
            return HTTPError(403, "Access denied.")
        if not os.path.exists(filename):
            return HTTPError(404, "File does not exist.")
        if not os.access(filename, os.R_OK):
             with utils.temporary_chown(filename):
                return static_file_or_dev(filename, root=root, mimetype='application/octet-stream', download=filename)
        return static_file_or_dev(filename, root=root, mimetype='application/octet-stream', download=filename)
    
    run(host='0.0.0.0', port=port, server='eventlet')
    
def static_file_or_dev(filename, root, mimetype='auto', download=False, charset='UTF-8'):
    """ Open a file in a safe way and return :exc:`HTTPResponse` with status
        code 200, 305, 403 or 404. The ``Content-Type``, ``Content-Encoding``,
        ``Content-Length`` and ``Last-Modified`` headers are set if possible.
        Special support for ``If-Modified-Since``, ``Range`` and ``HEAD``
        requests.

        :param filename: Name or path of the file to send.
        :param root: Root path for file lookups. Should be an absolute directory
            path.
        :param mimetype: Defines the content-type header (default: guess from
            file extension)
        :param download: If True, ask the browser to open a `Save as...` dialog
            instead of opening the file with the associated program. You can
            specify a custom filename as a string. If not specified, the
            original filename is used (default: False).
        :param charset: The charset to use for files with a ``text/*``
            mime-type. (default: UTF-8)
    """

    headers = dict()

    if not filename.startswith(root):
        return HTTPError(403, "Access denied.")
    if not os.path.exists(filename):
        return HTTPError(404, "File does not exist.")
    if not os.access(filename, os.R_OK):
        return HTTPError(403, "You do not have permission to access this file.")

    if mimetype == 'auto':
        mimetype, encoding = bottle.mimetypes.guess_type(filename)
        if encoding: headers['Content-Encoding'] = encoding

    if mimetype:
        if mimetype[:5] == 'text/' and charset and 'charset' not in mimetype:
            mimetype += '; charset=%s' % charset
        headers['Content-Type'] = mimetype

    if download:
        download = os.path.basename(filename if download == True else download)
        headers['Content-Disposition'] = 'attachment; filename="%s"' % download

    stats = os.stat(filename)
    headers['Content-Length'] = clen = stats.st_size
    lm = time.strftime("%a, %d %b %Y %H:%M:%S GMT", time.gmtime(stats.st_mtime))
    headers['Last-Modified'] = lm

    ims = bottle.request.environ.get('HTTP_IF_MODIFIED_SINCE')
    if ims:
        ims = bottle.parse_date(ims.split(";")[0].strip())
    if ims is not None and ims >= int(stats.st_mtime):
        headers['Date'] = time.strftime("%a, %d %b %Y %H:%M:%S GMT", time.gmtime())
        try:
            return  bottle.HTTPResponse(status=304, **headers)
        except Exception as ex:
            return bottle.HTTPResponse(status=304, header = headers)    

    body = '' if bottle.request.method == 'HEAD' else open(filename, 'rb')

    headers["Accept-Ranges"] = "bytes"
    ranges = bottle.request.environ.get('HTTP_RANGE')
    if 'HTTP_RANGE' in bottle.request.environ:
        ranges = list(bottle.parse_range_header(bottle.request.environ['HTTP_RANGE'], clen))
        if not ranges:
            return bottle.HTTPError(416, "Requested Range Not Satisfiable")
        offset, end = ranges[0]
        headers["Content-Range"] = "bytes %d-%d/%d" % (offset, end-1, clen)
        headers["Content-Length"] = str(end-offset)
        if body: body = bottle._file_iter_range(body, offset, end-offset)
        try:
            return  bottle.HTTPResponse(body, status=206, **headers)
        except Exception as ex:
            return bottle.HTTPResponse(body, status=206, header = headers)
    try:
        return  bottle.HTTPResponse(body, **headers)
    except Exception as ex:
        return bottle.HTTPResponse(body, header = headers)
