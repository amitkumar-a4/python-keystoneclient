# Copyright 2014 TrilioData Inc.
# All Rights Reserved.

import functools
import json
import webob
from webob import exc

from nova import exception as novaexc
from nova.api.openstack import common
from nova.api.openstack import extensions
from nova.api.openstack import wsgi
from nova.api.openstack.compute import servers
from nova.api.openstack.compute.views import servers as views_servers
from nova.openstack.common import log as logging

from nova.openstack.common.gettextutils import _

from contego.nova.api import API

LOG = logging.getLogger("nova.api.extensions.contego")

authorizer = extensions.extension_authorizer('compute', 'contego')

def convert_exception(action):

    def fn(self, *args, **kwargs):
        try:
            return action(self, *args, **kwargs)
        except novaexc.NovaException as error:
            raise exc.HTTPBadRequest(explanation=unicode(error))
    # Openstack sometimes does matching on the function name so we need to
    # ensure that the decorated function returns with the same function name as the action.
    fn.__name__ = action.__name__
    return fn

def authorize(f):
    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        context = kwargs['req'].environ["nova.context"]
        authorizer(context)
        return f(*args, **kwargs)
    return wrapper

class ContegoInfoController(object):

    def __init__(self):
        self.cobalt_api = API()

    @convert_exception
    @authorize
    def index(self, req):
        context = req.environ['nova.context']
        return webob.Response(status_int=200,
            body=json.dumps(self.contego_api.get_info()))
        
class ContegoServerControllerExtension(wsgi.Controller):
    """
    The OpenStack Extension definition for Contego capabilities. Currently this includes:
        * VAST an existing virtual machine
    """

    _view_builder_class = views_servers.ViewBuilder

    def __init__(self):
        super(ContegoServerControllerExtension, self).__init__()
        self.contego_api = API()
        self.nova_servers = servers.Controller()

        # Add the contego-specific states to the state map
        common._STATE_MAP['vasted'] = {'default': 'VASTED'}

    @wsgi.action('contego_vast_prepare')
    @convert_exception
    @authorize
    def _vast_prepare(self, req, id, body):
        context = req.environ["nova.context"]
        params = body.get('contego_vast_prepare', body.get('contego_vast_prepare', {}))
        result = self.contego_api.vast_prepare(context, id, params)
        return result
    
    @wsgi.action('contego_vast_freeze')
    @convert_exception
    @authorize
    def _vast_freeze(self, req, id, body):
        context = req.environ["nova.context"]
        params = body.get('contego_vast_freeze', body.get('contego_vast_freeze', {}))
        result = self.contego_api.vast_freeze(context, id, params)
        return result
    
    @wsgi.action('contego_vast_thaw')
    @convert_exception
    @authorize
    def _vast_thaw(self, req, id, body):
        context = req.environ["nova.context"]
        params = body.get('contego_vast_thaw', body.get('contego_vast_thaw', {}))
        result = self.contego_api.vast_thaw(context, id, params)
        return result        
        
    @wsgi.action('contego_vast_get_info')
    @convert_exception
    @authorize
    def _vast_get_info(self, req, id, body):
        context = req.environ["nova.context"]
        params = body.get('contego_vast_get_info', body.get('contego_vast_get_info', {}))
        result = self.contego_api.vast_get_info(context, id, params)
        return result

    @wsgi.action('contego_vast_instance')
    @convert_exception
    @authorize
    def _vast_instance(self, req, id, body):
        context = req.environ["nova.context"]
        params = body.get('contego_vast_instance', body.get('contego_vast_instance', {}))
        result = self.contego_api.vast_instance(context, id, params)
        return result

    @wsgi.action('contego_vast_data_url')
    @convert_exception
    @authorize
    def _vast_data_url(self, req, id, body):
        context = req.environ["nova.context"]
        params = body.get('contego_vast_data_url', body.get('contego_vast_data_url', {}))
        result = self.contego_api.vast_data_url(context, id, params)
        return result    
        
    @wsgi.action('contego_vast_data')
    @convert_exception
    @authorize
    def _vast_data(self, req, id, body):
        context = req.environ["nova.context"]
        params = body.get('contego_vast_data', body.get('contego_vast_data', {}))
        result = self.contego_api.vast_data(context, id, params)
        return result    
    
    @wsgi.action('contego_vast_finalize')
    @convert_exception
    @authorize
    def _vast_finalize(self, req, id, body):
        context = req.environ["nova.context"]
        params = body.get('contego_vast_finalize', body.get('contego_vast_finalize', {}))
        result = self.contego_api.vast_finalize(context, id, params)
        return result  
    
    @wsgi.action('contego_testbubble_attach_volume')
    @convert_exception
    @authorize
    def _testbubble_attach_volume(self, req, id, body):
        context = req.environ["nova.context"]
        params = body.get('contego_testbubble_attach_volume', body.get('contego_testbubble_attach_volume', {}))
        result = self.contego_api.testbubble_attach_volume(context, id, params)
        return result 
    
    @wsgi.action('contego_testbubble_reboot_instance')
    @convert_exception
    @authorize
    def _testbubble_reboot_instance(self, req, id, body):
        context = req.environ["nova.context"]
        params = body.get('contego_testbubble_reboot_instance', body.get('contego_testbubble_reboot_instance', {}))
        result = self.contego_api.testbubble_reboot_instance(context, id, params)
        return result    
        
class contego_extension(object):
    """
    The OpenStack Extension definition for the contego capabilities. Currently this includes:
    * VAST an instance
    """

    name = "Contego"
    alias = "CO"
    namespace = "http://docs.triliodata.com/openstack/ext/api/v1"
    updated = '2014-02-10T11:52:50-07:00' ##TIMESTAMP##

    def __init__(self, ext_mgr):
        ext_mgr.register(self)

    def get_resources(self):
        info_controller = ContegoInfoController()
        return [extensions.ResourceExtension('contegoinfo', info_controller),]

    def get_controller_extensions(self):
        extension_list = []
        extension_set = [(ContegoServerControllerExtension, 'servers'),]
        for klass, collection in extension_set:
            controller = klass()
            ext = extensions.ControllerExtension(self, collection, controller)
            extension_list.append(ext)

        return extension_list
