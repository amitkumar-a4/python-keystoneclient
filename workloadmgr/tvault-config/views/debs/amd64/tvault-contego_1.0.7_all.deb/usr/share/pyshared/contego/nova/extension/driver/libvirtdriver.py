# Copyright 2014 TrilioData Inc.
# All Rights Reserved.

try:
    from eventlet import sleep
except ImportError:
    from time import sleep
    
import os
import uuid
import shutil
import libvirt
import libvirt_qemu
import xml
import xml.dom
import xml.dom.minidom
import socket


from lxml import etree

from oslo.config import cfg

from nova.openstack.common.gettextutils import _
from nova.openstack.common import log as logging
from nova.openstack.common import fileutils
from nova.openstack.common import jsonutils
from nova import utils
from nova import exception
from nova.image import glance
from nova.virt.libvirt import driver
from nova.virt.libvirt import config as vconfig
from nova.virt.libvirt import utils as libvirt_utils
from nova.compute import power_state

from contego.nova.extension.driver import qemuimages 



contego_libvirt_opts = [
    cfg.BoolOpt('contego_libvirt_snapshot_compression',
                default=False,
                help='Compress snapshot images when possible. This '
                     'currently applies exclusively to qcow2 images'),
    ]

CONF = cfg.CONF
CONF.register_opts(contego_libvirt_opts)
CONF.import_opt('instances_path', 'nova.compute.manager')

LOG = logging.getLogger('nova.contego.driver.libvirtdriver')

def get_lan_ip():
    ip = socket.gethostbyname(socket.gethostname())
    if ip.startswith("127.") and os.name != "nt":
        interfaces = [
            "eth0",
            "eth1",
            "eth2",
            "wlan0",
            "wlan1",
            "wifi0",
            "ath0",
            "ath1",
            "ppp0",
            ]
        for ifname in interfaces:
            try:
                ip = get_interface_ip(ifname)
                break
            except IOError:
                pass
    return ip

class XMLElement(object):

    def __init__(self, tagName, text=None, **attrs):
        self._elem = xml.dom.minidom.Document().createElement(tagName)
        self.setAttrs(**attrs)
        if text is not None:
            self.appendTextNode(text)

    def __getattr__(self, name):
        return getattr(self._elem, name)

    def setAttrs(self, **attrs):
        for attrName, attrValue in attrs.iteritems():
            self._elem.setAttribute(attrName, attrValue)

    def appendTextNode(self, text):
        textNode = xml.dom.minidom.Document().createTextNode(text)
        self._elem.appendChild(textNode)

    def appendChild(self, element):
        self._elem.appendChild(element)

    def appendChildWithArgs(self, childName, text=None, **attrs):
        child = XMLElement(childName, text, **attrs)
        self._elem.appendChild(child)
        return child

class ChunkedFile(object):

    """
    We send this back to the  as
    something that can iterate over a large file
    """

    CHUNKSIZE = 65536

    def __init__(self, filepath):
        self.filepath = filepath
        self.fp = open(self.filepath, 'rb')

    def __iter__(self):
        """Return an iterator over the image file"""
        try:
            if self.fp:
                while True:
                    chunk = self.fp.read(ChunkedFile.CHUNKSIZE)
                    if chunk:
                        yield chunk
                    else:
                        break
        finally:
            self.close()

    def close(self):
        """Close the internal file pointer"""
        if self.fp:
            self.fp.close()
            self.fp = None
            
def cooperative_iter(iter):
    """
    Return an iterator which schedules after each
    iteration. This can prevent eventlet thread starvation.

    :param iter: an iterator to wrap
    """
    try:
        for chunk in iter:
            sleep(0)
            yield chunk
    except Exception as err:
        msg = _("Error: cooperative_iter exception %s") % err
        LOG.error(msg)
        raise
                
class LibvirtDriver():

    def __init__(self, virt_driver, read_only=False):
        self.virt_driver = virt_driver
        
    def _add_line(self, file_path, add_line, location_pattern, after=True):
        lines = []
        with open(file_path) as file:
            for line in file:
                lines.append(line)
        with open(file_path, 'w') as file:
            for line in lines:
                if location_pattern in line:
                    if not after:
                        file.write(add_line+'\n')
                    file.write(line)
                    if after:
                        file.write(add_line+'\n')                
                else:
                    file.write(line) 
        
    def _remove_line(self, file_path, remove_line):
        lines = []
        with open(file_path) as file:
            for line in file:
                lines.append(line)

        with open(file_path, 'w') as file:
            for line in lines:
                if remove_line in line:
                    continue
                else:
                    file.write(line)
                    
        
    def _configure_apparmor_profile(self, instance_uuid):
        try:
            apparmor_profile = '/etc/apparmor.d/libvirt/libvirt-' + instance_uuid
            # save original file ownership details
            stat = os.stat(apparmor_profile)
            uid, gid = stat[4], stat[5]
            libvirt_utils.chown(apparmor_profile, os.getuid()) 
            acl = '  "' + CONF.instances_path + '/*/*" rw,' 
            self._add_line(apparmor_profile, acl, '#include <libvirt/libvirt-' + instance_uuid )
            libvirt_utils.chown(apparmor_profile, uid)
        except Exception as err:
            msg = _("Error: configuring app armor profile %s") % err
            LOG.error(msg)
            libvirt_utils.chown(apparmor_profile, 0)

                
    def _reset_apparmor_profile(self, instance_uuid):
        try:
            apparmor_profile = '/etc/apparmor.d/libvirt/libvirt-' + instance_uuid
            # save original file ownership details
            stat = os.stat(apparmor_profile)
            uid, gid = stat[4], stat[5]
            libvirt_utils.chown(apparmor_profile, os.getuid()) 
            acl = '  "' + CONF.instances_path + '/*/*" rw,' 
            self._remove_line(apparmor_profile, acl)
            libvirt_utils.chown(apparmor_profile, uid)
        except Exception as err:
            msg = _("Error: resetting app armor profile %s") % err
            LOG.error(msg)
            libvirt_utils.chown(apparmor_profile, 0)
        
    def get_instance_name_by_uuid(self, instance_uuid):
        for name in self.virt_driver.list_instances():
            if self.virt_driver._conn.lookupByName(name).UUIDString() == instance_uuid:
                return name
        return None 

    def get_disk_backing_file(self, path, basename=True):
        """
        Get the backing file of a disk image
        :param path: Path to the disk image
        :returns: a path to the image's backing store
        """
        backing_file = qemuimages.qemu_img_info(path).backing_file
        if backing_file and basename:
            backing_file = os.path.basename(backing_file)
        
        return backing_file
    
    def get_instance_disks_info(self, instance_name):
        """
        Note that this function takes an instance name.
        Returns a list of all block devices for this domain.
        "[{'dev':'vda', 'path':'filepath'},...]"        
        """
        domain = self.virt_driver._conn.lookupByName(instance_name)
        xml = domain.XMLDesc(0)

        disks_info = []
        doc = etree.fromstring(xml)
        disk_nodes = doc.findall('.//devices/disk')
        path_nodes = doc.findall('.//devices/disk/source')
        driver_nodes = doc.findall('.//devices/disk/driver')
        target_nodes = doc.findall('.//devices/disk/target')

        for cnt, path_node in enumerate(path_nodes):
            disk_type = disk_nodes[cnt].get('type')
            path = path_node.get('file')
            if not path:
                path = path_node.get('dev')
            dev = target_nodes[cnt].attrib['dev']

            if not path:
                LOG.debug(_('skipping disk for %s as it does not have a path'),instance_name)
                continue
            
            backings = [] # using list as a stack for the disk backings
            backing_path = self.get_disk_backing_file(path, basename=False)        
            while (backing_path != None):
                urls = []
                urls.append( backing_path.replace(CONF.instances_path, 
                                                  'http://' + get_lan_ip() + ':' + str(CONF.contego_vast_data_listen_port) + '/vastdata', 1))
                urls.append( backing_path.replace(CONF.instances_path,
                                                  'http://' + socket.gethostname() + ':' + str(CONF.contego_vast_data_listen_port) + '/vastdata', 1)) 
                backing_size = int(os.path.getsize(backing_path))               
                backing = {'path': backing_path, 
                           'size': backing_size,
                           'urls': urls,
                           }
                backings.append(backing)
                backing_path = self.get_disk_backing_file(backing_path, basename=False)
            
            urls = []
            urls.append( path.replace(CONF.instances_path, 
                                              'http://' + get_lan_ip() + ':' + str(CONF.contego_vast_data_listen_port) + '/vastdata', 1))
            urls.append( path.replace(CONF.instances_path,
                                              'http://' + socket.gethostname() + ':' + str(CONF.contego_vast_data_listen_port) + '/vastdata', 1)) 
            size = int(os.path.getsize(path))            
            disk_info = {'dev': dev, 
                         'path': path,
                         'size': size,
                         'urls': urls,
                         'backings': backings}
            disks_info.append(disk_info)
            
        return disks_info              

    def snapshot_create_as(self, instance_uuid, instance_name, snapshot_name, snapshot_description, dev_snapshot_disk_paths):
        """Atomic disk only external snapshots of an instance
        Todo: use virDomainSnapshotCreateXML instead of virsh

        :param instance: instance to snapshot
        :param snapshot_name: Name of snapshot
        :param snapshot_description: Description of snapshot
        :param snapshot_disk_paths: list of the new snapshot_disk_paths
        """
        domain = self.virt_driver._conn.lookupByName(instance_name)    
        snap = xml.dom.minidom.Element('domainsnapshot')
        disks = xml.dom.minidom.Element('disks')    
        for dev, snapshot in dev_snapshot_disk_paths.iteritems():
            disk = XMLElement('disk', name=dev, snapshot='external')
            disk.appendChildWithArgs('source', file=snapshot)
            disks.appendChild(disk)
        snap.appendChild(disks)
        snapxml = snap.toprettyxml()
        snapFlags = (libvirt.VIR_DOMAIN_SNAPSHOT_CREATE_DISK_ONLY |
                     libvirt.VIR_DOMAIN_SNAPSHOT_CREATE_NO_METADATA)
        
        try: 
            self._configure_apparmor_profile(instance_uuid)
        except Exception as err:
            msg = _("Error: configuring app armor profile %s") % err
            LOG.error(msg)
       
        try:
            domain.snapshotCreateXML(snapxml, snapFlags)
            try:
                self._reset_apparmor_profile(instance_uuid)
            except:
                pass
        except Exception as err:
            msg = _("Error: Creating Snapshot - %s") % err
            LOG.error(msg)
            try: 
                self._reset_apparmor_profile(instance_uuid)
            except Exception as err2:
                msg = _("Error: resetting app armor profile %s") % err
                LOG.error(msg)
            raise err
            
        for dev, snapshot in dev_snapshot_disk_paths.iteritems():
            utils.execute('chmod', '0664', snapshot, run_as_root=True)           
        
    def snapshot_delete(self, instance_name, snapshot_name, metadata = False):
        """delete the snapshot
        Todo: use virDomainXXX instead of virsh

        :param instance: instance of snapshot
        :param snapshot_name: Name of snapshot
        :param metadata: If True, delete the metadata only
        """
        pass     
        
    def rebase_qcow2(self, backing_file_base, backing_file_top):
        """rebase the backing_file_top to backing_file_base using unsafe mode
        :param backing_file_base: backing file to rebase to
        :param backing_file_top: top file to rebase
        """
        utils.execute('env', 'LC_ALL=C', 'LANG=C',
                      'qemu-img', 'rebase', '-u', '-b', backing_file_base, backing_file_top, run_as_root=True)
   

    def commit_qcow2(self, backing_file_top):
        """rebase the backing_file_top to backing_file_base
         :param backing_file_top: top file to commit from to its base
        """
        utils.execute('env', 'LC_ALL=C', 'LANG=C',
                      'qemu-img', 'commit', backing_file_top, run_as_root=True)

    def blockcommit(self, instance_name, dev, backing_file_base, backing_file_top):
        """block commit the changes from top to base
        Todo: use virDomainXXX instead of virsh

        :param instance: instance to blockcommit
        :param dev: block device name
        :param backing_file_base: base to commit into
        :param backing_file_top: top file to commit from
        """
        domain = self.virt_driver._conn.lookupByName(instance_name)    
        commitFlags = 0 #(libvirt.VIR_DOMAIN_BLOCK_COMMIT_DELETE) 
        domain.blockCommit(dev, backing_file_base, backing_file_top, 0, 0)
        while True:
            #TODO(giri): implement a timeout
            blockjobinfoFlags = 0 #libvirt.VIR_DOMAIN_BLOCK_JOB_TYPE_COMMIT
            ret = domain.blockJobInfo(dev, blockjobinfoFlags)
            if ret == None:
                break
            if ret == {}:
                break
            if 'cur' in ret and 'end' in ret:
                LOG.debug(_(" blockcommit cur:" + str(ret['cur']) + " end:" + str(ret['end'])))
                if ret['cur'] == ret['end']:
                    break
            sleep(5)
            
    def commit_disk_chain(self, instance_name, instance_ref, disk_info):
        #Walk the qcow2 for each disk device and commit any intermediate qcow2 files into base
        state = self.virt_driver.get_info(instance_ref)['state']  
        current_file = disk_info['path']
        backing_file = self.get_disk_backing_file(current_file, basename=False)
        backing_file_backing = self.get_disk_backing_file(backing_file, basename=False)
        
        while(backing_file_backing != None and backing_file_backing != backing_file):
            if disk_info['dev'] == 'vda':
                # Base image can be shared by multiple instances...should leave a minimum of two files behind the current file
                backing_file_backing_backing = self.get_disk_backing_file(backing_file_backing, basename=False)
                if(backing_file_backing_backing == None or backing_file_backing_backing == backing_file_backing):
                    break
            if (state == power_state.RUNNING or state == power_state.PAUSED ): 
                #If the instance is running we will do a blockcommit
                #TODO(gbasava): verify if blockcommit will work on only for the first file, but down the chain of the qcow2 files
                self.blockcommit(instance_name, disk_info['dev'], backing_file_backing, backing_file)
                fileutils.delete_if_exists(backing_file)
            elif (state == power_state.SHUTDOWN or  state == power_state.SUSPENDED ): #commit and rebase
                self.commit_qcow2(backing_file)
                fileutils.delete_if_exists(backing_file)                     
                self.rebase_qcow2(backing_file_backing, current_file)
            else: 
                #TODO(gbasava): investigate and handle other powerstates
                pass
            backing_file = self.get_disk_backing_file(current_file, basename=False)
            backing_file_backing = self.get_disk_backing_file(backing_file, basename=False)
        
    @exception.wrap_exception()
    def vast_prepare(self, context, instance_uuid, instance_ref, params):
        pass
    
    def _quiesce(self, context, instance_uuid, quiesce):
        
        instance_name = self.get_instance_name_by_uuid(instance_uuid)
        if quiesce:
            command = '{"execute":"guest-fsfreeze-freeze"}'
            status = 'freezing guest filesystems'
            LOG.debug(_('freezing guest filesystems of %s'), instance_name)
        else:
            command = '{"execute":"guest-fsfreeze-thaw"}'
            status = 'thawing guest filesystems'
            LOG.debug(_('Thawing guest filesystems of %s'), instance_name)
        try:
            domain = self.virt_driver._conn.lookupByName(instance_name)
            ret = libvirt_qemu.qemuAgentCommand(domain, command, 60, 0)
        except Exception as ex:
            error_code = ex.get_error_code()
            msg = (_('Error from libvirt while ' + status + ' of '
                     '%(instance_name)s: [Error Code %(error_code)s] %(ex)s') %
                   {'instance_name': instance_name, 'error_code': error_code,
                    'ex': ex})
            raise exception.NovaException(msg)
        result = jsonutils.loads(ret)
        if hasattr(result, 'error'):
            msg = (_('Error from qemu-guest-agent while ' + status + ' of '
                     '%(instance_name)s: %(error)s') %
                   {'instance_name': instance_name, 'error': ret})
            raise exception.NovaException(msg)
    
    
    @exception.wrap_exception()
    def vast_freeze(self, context, instance_uuid, instance_ref, params):
        return self._quiesce(context, instance_uuid, True )  
    
    @exception.wrap_exception()
    def vast_thaw(self, context, instance_uuid, instance_ref, params):
        return self._quiesce(context, instance_uuid, False )    
    
    @exception.wrap_exception()
    def vast_instance(self, context, instance_uuid, instance_ref, params):
        
        instance_name = self.get_instance_name_by_uuid(instance_uuid)
        snapshot_directory = os.path.join(CONF.instances_path, instance_uuid)
        fileutils.ensure_tree(snapshot_directory)
        snapshot_name = uuid.uuid4().hex
        snapshot_description = "snapshot_" + params['snapshot_id'] + "of_workload_" + params['workload_id']
        dev_snapshot_disk_paths = {} # Dictionary that holds dev and snapshot_disk_path
        devices = self.virt_driver.get_disks(instance_name)
        for device in devices:
            dev_snapshot_disk_paths.setdefault(device, 
                        snapshot_directory + '/' + snapshot_name + '_' + device + '.qcow2' )

        self.snapshot_create_as(instance_uuid, instance_name, snapshot_name, snapshot_description, dev_snapshot_disk_paths)
        # TODO(giri): handle the failure of snapshot_create_as
        
        #delete snapshot : metadata only
        self.snapshot_delete(instance_name, snapshot_name, True)

    @exception.wrap_exception()
    def vast_get_info(self, context, instance_uuid, instance_ref, params):
       
        instance_name = self.get_instance_name_by_uuid(instance_uuid)
        return {'info' : self.get_instance_disks_info(instance_name)}
        
    @exception.wrap_exception()
    def vast_data(self, context, instance_uuid, instance_ref, params):
        path = params['path']
        size = int(os.path.getsize(path)) 
        return {
            'iterator': ChunkedFile(path),
            'size': size,
        }
    
    @exception.wrap_exception()
    def vast_finalize(self, context, instance_uuid, instance_ref, params):
               
        instance_name = self.get_instance_name_by_uuid(instance_uuid)
        disks_info = self.get_instance_disks_info(instance_name)
        for disk_info in disks_info: 
            self.commit_disk_chain(instance_name, instance_ref, disk_info)
            
    @exception.wrap_exception()
    def testbubble_attach_volume(self, context, instance_uuid, instance_ref, params):
        instance_dir = libvirt_utils.get_instance_path(instance_uuid)
        #TODO(giri): May be we don't have to move the file. If the source is on tVaultFS
        #we won't be able to move the file
        shutil.move(params['path'], instance_dir)
        volume_file_path = os.path.join(instance_dir, os.path.basename(params['path']))
        
        instance_name = self.get_instance_name_by_uuid(instance_uuid)
        virt_dom = self.virt_driver._conn.lookupByName(instance_name)
        disk_dev = params['mountpoint'].rpartition("/")[2]
        conf = vconfig.LibvirtConfigGuestDisk()
        conf.driver_cache = 'writethrough'
        conf.driver_name = 'qemu'
        conf.device_type = 'disk'
        conf.driver_format = "raw"
        conf.driver_cache = "none"
        conf.target_dev = disk_dev
        conf.target_bus = 'scsi'
        #conf.serial = 'serial'
        conf.source_type = 'file'
        conf.source_path = volume_file_path         

        try:
            # NOTE(vish): We can always affect config because our
            #             domains are persistent, but we should only
            #             affect live if the domain is running.
            flags = libvirt.VIR_DOMAIN_AFFECT_CONFIG
            state = self.virt_driver.get_info(instance_ref)['state']
            if state == power_state.RUNNING:
                flags |= self.virt_driver.VIR_DOMAIN_AFFECT_LIVE
            virt_dom.attachDeviceFlags(conf.to_xml(), flags)
        except Exception, ex:
            return        
    
    @exception.wrap_exception()
    def testbubble_reboot_instance(self, context, instance_uuid, instance_ref, params):
        #support simple reboot unlike nova soft and hard reboot
        if(params['reboot_type'] == 'SIMPLE'):
            instance_name = self.get_instance_name_by_uuid(instance_uuid)
            virt_dom = self.virt_driver._conn.lookupByName(instance_name)
            virt_dom.reboot(0)            
 