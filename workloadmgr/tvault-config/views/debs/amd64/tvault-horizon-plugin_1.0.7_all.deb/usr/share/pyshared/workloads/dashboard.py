# vim: tabstop=4 shiftwidth=4 softtabstop=4

# Copyright 2014 TrilioData Inc.
# All Rights Reserved.


from django.utils.translation import ugettext as _

import horizon


class WorkloadsPlugin(horizon.Dashboard):
    name = _("Workloads")
    slug = "Workloads"
    panels = ('Workloads',)
    default_panel = 'Workloads'
    nav = True


horizon.register(AnimalsPlugin)