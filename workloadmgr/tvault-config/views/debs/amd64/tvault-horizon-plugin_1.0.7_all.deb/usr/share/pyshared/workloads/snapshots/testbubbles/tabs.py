# vim: tabstop=4 shiftwidth=4 softtabstop=4

# Copyright (c) 2013 TrilioData, Inc.

import logging

from django.core.urlresolvers import reverse
from django.utils.translation import ugettext_lazy as _

from horizon import exceptions
from horizon import tabs

from openstack_dashboard import api

LOG = logging.getLogger(__name__)


class OverviewTab(tabs.Tab):
    name = _("Overview")
    slug = "overview"
    template_name = "project/workloads/snapshots/testbubbles/_detail_overview.html"

    def get_context_data(self, request):
        testbubble_id = self.tab_group.kwargs['testbubble_id']
        try:
            testbubble = workloadmgr.testbubble_get(self.request, testbubble_id)
        except:
            redirect = reverse('horizon:project:workloads:snapshots:index')
            msg = _('Unable to retrieve testbubble details.')
            exceptions.handle(request, msg, redirect=redirect)
        return {'testbubble': testbubble}


class TestbubbleDetailTabs(tabs.TabGroup):
    slug = "testbubble_details"
    tabs = (OverviewTab,)
