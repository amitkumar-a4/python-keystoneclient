# vim: tabstop=4 shiftwidth=4 softtabstop=4

# Copyright (c) 2013 TrilioData, Inc.


import logging

from workloadmgrclient.v1 import client as workloadmgrclient

from django.conf import settings

from horizon import exceptions

from openstack_dashboard.api.base import url_for, APIDictWrapper


LOG = logging.getLogger(__name__)
FOLDER_DELIMITER = "/"


def workload_api(request):
    insecure = getattr(settings, 'OPENSTACK_SSL_NO_VERIFY', False)
    workloadmgr_url = ""
    try:
        workloadmgr_url = url_for(request, 'workloads')
    except exceptions.ServiceCatalogException:
        LOG.debug('no workloads service configured.')
        return None

    LOG.debug('workloadmgr connection created using token "%s" and url "%s"' %
              (request.user.token.id, workloadmgr_url))
    c = workloadmgrclient.Client(request.user.username,
                             request.user.token.id,
                             project_id=request.user.tenant_id,
                             auth_url=workloadmgr_url,
                             insecure=insecure,
                             http_log_debug=settings.DEBUG)
    c.client.auth_token = request.user.token.id
    c.client.management_url = workloadmgr_url
    return c

def workload_type_get(request, workload_type_id):
    try:
        workload_type = workload_api(request).workload_types.get(workload_type_id)
        return workload_type
    except :
        return None

def workload_type_list(request):
    workload_types = workload_api(request).workload_types.list()
    return workload_types

def workload_type_create(request, context):
    workload_type = workload_api(request).workload_types.create(context['metadata'],
                                                                context['name'],
                                                                context['description'])
    return workload_type

def workload_type_delete(request, workload_type_id):
    workload_api(request).workload_types.delete(workload_type_id)
    return True

def workload_get(request, workload_id):
    try:
        workload = workload_api(request).workloads.get(workload_id)
        return workload
    except :
        return None


def workload_list(request):
    workloads = workload_api(request).workloads.list()
    return workloads

def workload_create(request, context):
    metadata = {}
    workload = workload_api(request).workloads.create(context['name'],
                                                      context['description'],
                                                      context['workload_type'],
                                                      context['instances'],
                                                      context['jobschedule'],
                                                      metadata)
    return workload

def workload_snapshot(request, workload_id, full=False):
    return workload_api(request).workloads.snapshot(workload_id,full)

def workload_delete(request, workload_id):
    workload_api(request).workloads.delete(workload_id)
    return True

def snapshot_get(request, snapshot_id):
    try:
        snapshot = workload_api(request).snapshots.get(snapshot_id)
        return snapshot
    except :
        return None

def snapshot_list(request, workload_id):
    search_opts = {'workload_id': workload_id}
    snapshots = workload_api(request).snapshots.list(detailed=True, search_opts=search_opts)
    return snapshots
                   
def snapshot_restore(request, snapshot_id, test=False):    
    workload_api(request).snapshots.restore(snapshot_id,test)
    return True
    
def snapshot_delete(request, snapshot_id):
    workload_api(request).snapshots.delete(snapshot_id)
    return True

def restore_get(request, restore_id):
    try:
        restore = workload_api(request).restores.get(restore_id)
        return restore
    except :
        return None

def restore_list(request, snapshot_id):
    search_opts = {'snapshot_id': snapshot_id}
    restores = workload_api(request).restores.list(detailed=True, search_opts=search_opts)
    return restores
                   
def restore_delete(request, restore_id):
    workload_api(request).restores.delete(restore_id)
    return True    

def testbubble_get(request, testbubble_id):
    try:
        testbubble = workload_api(request).testbubbles.get(testbubble_id)
        return testbubble
    except :
        return None

def testbubble_list(request, snapshot_id):
    search_opts = {'snapshot_id': snapshot_id}
    testbubbles = workload_api(request).testbubbles.list(detailed=True, search_opts=search_opts)
    return testbubbles
                   
def testbubble_delete(request, testbubble_id):
    workload_api(request).testbubbles.delete(testbubble_id)
    return True        

