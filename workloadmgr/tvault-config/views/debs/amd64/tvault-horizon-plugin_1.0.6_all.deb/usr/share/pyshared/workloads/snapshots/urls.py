# Copyright (c) 2014 TrilioData, Inc.
# All Rights Reserved.

from django.conf.urls.defaults import patterns, url

from .views import DetailView


SNAPSHOTS = r'^(?P<snapshot_id>[^/]+)/%s$'
VIEW_MOD = 'openstack_dashboard.dashboards.project.workloads.snapshots.views'


urlpatterns = patterns(VIEW_MOD,
    url(SNAPSHOTS % 'detail', DetailView.as_view(), name='detail')
)
