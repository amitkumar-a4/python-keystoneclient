# Copyright (c) 2014 TrilioData, Inc.
# All Rights Reserved.

from django.conf.urls.defaults import patterns, url, include

from .views import IndexView, CreateView, DetailView
from .snapshots import urls as snapshot_urls


WORKLOADS = r'^(?P<workload_id>[^/]+)/%s$'

urlpatterns = patterns('openstack_dashboard.dashboards.project.workloads.views',
    url(r'^$', IndexView.as_view(), name='index'),
    url(r'^create$', CreateView.as_view(), name='create'),
    #url(WORKLOADS % 'detail', DetailView.as_view(), name='detail'),
    url(r'^(?P<workload_id>[^/]+)/$',DetailView.as_view(), name='detail'),    
    url(r'^snapshots/', include(snapshot_urls, namespace='snapshots'))
)