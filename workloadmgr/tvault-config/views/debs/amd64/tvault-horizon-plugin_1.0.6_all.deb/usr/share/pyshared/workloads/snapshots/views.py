# Copyright (c) 2014 TrilioData, Inc.
# All Rights Reserved.

"""
Views for managing WorkloadMgr Snapshots.
"""
import logging

from django.core.urlresolvers import reverse_lazy
from django.utils.translation import ugettext_lazy as _

from horizon import exceptions
from horizon import forms
from horizon import tables
from horizon import workflows

from openstack_dashboard import api
from workloads import workloadmgr
from .tables import SnapshotsTable
from restores.tables import RestoresTable
from testbubbles.tables import TestbubblesTable


LOG = logging.getLogger(__name__)

class IndexView(tables.DataTableView):
    table_class = SnapshotsTable
    template_name = 'project/workloads/snapshots/index.html'

    def get_data(self):
        try:
            snapshots = workloadmgr.snapshot_list(self.request)
        except:
            snapshots = []
            msg = _('Snapshot list can not be retrieved.')
            exceptions.handle(self.request, msg)

        return snapshots


class DetailView(tables.MultiTableView):
    table_classes = (RestoresTable, TestbubblesTable)
    template_name = 'project/workloads/snapshots/detail.html'
    failure_url = reverse_lazy('horizon:project:workloads:snapshots:index')

    def get_restores_data(self):
        try:
            snapshot = self._get_data()
            restores = workloadmgr.restore_list(self.request,snapshot_id=snapshot.id)
        except:
            restores = []
            msg = _('Restores list can not be retrieved.')
            exceptions.handle(self.request, msg)
        return restores
    
    def get_testbubbles_data(self):
        try:
            snapshot = self._get_data()
            testbubbles = workloadmgr.testbubble_list(self.request,snapshot_id=snapshot.id)
        except:
            testbubbles = []
            msg = _('Testbubbles list can not be retrieved.')
            exceptions.handle(self.request, msg)
        return testbubbles   
        
    def _get_data(self):
        if not hasattr(self, "_snapshot"):
            try:
                snapshot_id = self.kwargs['snapshot_id']
                snapshot = workloadmgr.snapshot_get(self.request, snapshot_id)
            except:
                msg = _('Unable to retrieve details for snapshot "%s".') \
                      % (snapshot_id)
                exceptions.handle(self.request, msg, redirect=self.failure_url)
            self._snapshot = snapshot
        return self._snapshot

    def get_context_data(self, **kwargs):
        context = super(DetailView, self).get_context_data(**kwargs)
        context["snapshot"] = self._get_data()
        return context

