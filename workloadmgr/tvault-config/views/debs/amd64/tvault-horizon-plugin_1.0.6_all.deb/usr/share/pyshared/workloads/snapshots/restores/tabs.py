# vim: tabstop=4 shiftwidth=4 softtabstop=4

# Copyright (c) 2013 TrilioData, Inc.

import logging

from django.core.urlresolvers import reverse
from django.utils.translation import ugettext_lazy as _

from horizon import exceptions
from horizon import tabs

from openstack_dashboard import api


LOG = logging.getLogger(__name__)


class OverviewTab(tabs.Tab):
    name = _("Overview")
    slug = "overview"
    template_name = "project/workloads/snapshots/restores/_detail_overview.html"

    def get_context_data(self, request):
        restore_id = self.tab_group.kwargs['restore_id']
        try:
            restore = workloadmgr.restore_get(self.request, restore_id)
        except:
            redirect = reverse('horizon:project:workloads:snapshots:index')
            msg = _('Unable to retrieve restore details.')
            exceptions.handle(request, msg, redirect=redirect)
        return {'restore': restore}


class RestoreDetailTabs(tabs.TabGroup):
    slug = "restore_details"
    tabs = (OverviewTab,)
