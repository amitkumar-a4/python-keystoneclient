# Copyright (c) 2014 TrilioData, Inc.
# All Rights Reserved.


import logging
import netaddr

from django.core.urlresolvers import reverse
from django.utils.translation import ugettext_lazy as _

from horizon import exceptions
from horizon import forms
from horizon import messages
from horizon import workflows
from horizon.utils import fields

from openstack_dashboard import api
from workloads import workloadmgr
from openstack_dashboard.api import nova
from openstack_dashboard.usage import quotas

LOG = logging.getLogger(__name__)


class SelectProjectUserAction(workflows.Action):
    project_id = forms.ChoiceField(label=_("Project"))
    user_id = forms.ChoiceField(label=_("User"))

    def __init__(self, request, *args, **kwargs):
        super(SelectProjectUserAction, self).__init__(request, *args, **kwargs)
        # Set our project choices
        projects = [(tenant.id, tenant.name)
                    for tenant in request.user.authorized_tenants]
        self.fields['project_id'].choices = projects

        # Set our user options
        users = [(request.user.id, request.user.username)]
        self.fields['user_id'].choices = users

    class Meta:
        name = _("Project & User")
        # Unusable permission so this is always hidden. However, we
        # keep this step in the workflow for validation/verification purposes.
        permissions = ("!",)


class SelectProjectUser(workflows.Step):
    action_class = SelectProjectUserAction
    contributes = ("project_id", "user_id")

class SetWorkloadDetailsAction(workflows.Action):
    name = forms.CharField(max_length=80, label=_("Workload Name"))
    description = forms.CharField(max_length=1024, required=False, label=_("Workload Description"))
    workload_type = forms.ChoiceField(label=_("Workload Type"),
                               help_text=_("Type of Workload"))    

    class Meta:
        name = _("Details")
        help_text_template = ("project/workloads/"
                              "_workload_details_help.html")
        
    def populate_workload_type_choices(self, request, context):
        """
        returns the available workload_types
        """
        try:
            workload_types = workloadmgr.workload_type_list(request)
            workload_type_list = [(workload_type.id, "%s" % workload_type.name)
                                   for workload_type in workload_types]
        except Exception:
            workload_type_list = []
            exceptions.handle(request,_('Unable to retrieve workload_types'))
        return workload_type_list

    def clean(self):
        cleaned_data = super(SetWorkloadDetailsAction, self).clean()

        # Validate our instance source.
        name = cleaned_data['name']
        if name == None or name == '':
            raise forms.ValidationError(_("There is no name for workload"))
        if not cleaned_data['name']:
            raise forms.ValidationError(_("Please enter name of the workload"))

        return cleaned_data

class SetWorkloadDetails(workflows.Step):
    action_class = SetWorkloadDetailsAction
    contributes = ("name", "description", "workload_type")

"""
    def contribute(self, data, context):
        context = super(SetWorkloadDetails, self).contribute(data, context)

        # Translate form input to context for name values.
        if 'name' in data:
            context['name'] = data.get(data['name'], None)

        if 'description' in data:
            context['description'] = data.get(data['description'], None)

        return context
"""

class SetInstancesAction(workflows.Action):
    instances = forms.MultipleChoiceField(label=_("Instances"),
                                        required=True,
                                        widget=forms.CheckboxSelectMultiple(),
                                        error_messages={
                                            'required': _(
                                                "At least one instance must"
                                                " be specified.")},
                                        help_text=_("Create workload with"
                                                    "these instances"))

    class Meta:
        name = _("Instances")
        permissions = ('openstack.services.compute',)
        help_text = _("Select instances for your workload.")

    def populate_instances_choices(self, request, context):
        try:
            tenant_id = self.request.user.tenant_id
            instances, more = api.nova.server_list(request)
            instance_list = [(instance.id, instance.name) for instance in instances]
        except:
            instance_list = []
            exceptions.handle(request,
                              _('Unable to retrieve instances.'))
        return instance_list

class SetInstances(workflows.Step):
    action_class = SetInstancesAction
    template_name = "project/workloads/_update_instances.html"
    contributes = ("instances",)

    def contribute(self, data, context):
        if data:
            instance_list = self.workflow.request.POST.getlist("instances")
            if instance_list:
                instances = []
                for instance in instance_list:
                    instances.append({'instance-id': instance })
                context['instances'] = instances
        return context

class SetSnapshotScheduleAction(workflows.Action):
    start_date = forms.DateField(input_formats=("%m/%d/%Y",), label=_("Start Date"),
                                 required=False,
                                 help_text=_("Start Date. mm/dd/yyyy"))
    end_date = forms.DateField(input_formats=("%m/%d/%Y",), label=_("End Date"),
                                 required=False,
                                 help_text=_("End Date. mm/dd/yyyy"))
    start_time = forms.TimeField(input_formats=("%H","%H:%M", "%I %p", "%I:%M %p"), label=_("Start Time"),
                                 required=False,
                                 help_text=_("Start Time. Example: 14:30"))
    interval = forms.CharField(max_length=80, label=_("Repeat Every"),
                                 required=False,
                                 help_text=_("Repeat Interval. Example: 1 hr OR 2 hrs OR 2 days OR 1 week"))
    snapshots_to_keep = forms.IntegerField(min_value=1, label=_("Snapshots to Keep"),
                                 required=False,
                                 help_text=_("Number of snapshots to retain"))    
    
    class Meta:
        name = _("Snapshot Schedule")
        help_text_template = ("project/workloads/"
                              "_create_schedule_help.html")


class SetSnapshotSchedule(workflows.Step):
    action_class = SetSnapshotScheduleAction
    contributes = ("jobschedule",)

    def contribute(self, data, context):
        if data:
            context['jobschedule'] = jobschedule = {}
            if hasattr(data['start_date'], 'strftime'):
                jobschedule['start_date'] = data['start_date'].strftime('%m/%d/%Y')
            else:
                return context
            if hasattr(data['end_date'], 'strftime'):
                jobschedule['end_date'] = data['end_date'].strftime('%m/%d/%Y')
            else:
                return context  
            if hasattr(data['start_time'], 'strftime'):
                jobschedule['start_time'] = data['start_time'].strftime('%I:%M%p')
            else:
                return context                       
            jobschedule['interval'] = data['interval']
            jobschedule['snapshots_to_keep'] = data['snapshots_to_keep']
            context['jobschedule'] = jobschedule
        return context

class CreateWorkload(workflows.Workflow):
    slug = "create_workload"
    name = _("Create Workload")
    finalize_button_name = _("Create")
    success_message = _('Create a workload named "%(name)s".')
    failure_message = _('Unable to create workload named "%(name)s".')
    default_steps = (SelectProjectUser,
                     SetWorkloadDetails,
                     SetInstances,
                     SetSnapshotSchedule)


    def get_success_url(self):
        return reverse("horizon:project:workloads:index")

    def get_failure_url(self):
        return reverse("horizon:project:workloads:index")

    def format_status_message(self, message):
        name = self.context.get('name', '')
        return message % {"name": name}

    def handle(self, request, data):
        try:
            workloadmgr.workload_create(request, context = self.context)
            return True
        except:
            exceptions.handle(request)
            return False
