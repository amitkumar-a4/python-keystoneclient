# Copyright (c) 2014 TrilioData, Inc.
# All Rights Reserved.

"""
Views for managing WorkloadMgr Workloads.
"""
import logging

from django.core.urlresolvers import reverse_lazy
from django.utils.translation import ugettext_lazy as _

from horizon import exceptions
from horizon import forms
from horizon import tables
from horizon import workflows

from openstack_dashboard import api
from workloads import workloadmgr
from .tables import WorkloadsTable
from .tables import WorkloadTypesTable
from .snapshots.tables import SnapshotsTable
from .workflows import CreateWorkload


LOG = logging.getLogger(__name__)


class IndexView(tables.MultiTableView):
    table_class = WorkloadsTable
    table_classes = (WorkloadsTable, WorkloadTypesTable)
    template_name = 'project/workloads/index.html'

    def get_workloads_data(self):
        try:
            workloads = workloadmgr.workload_list(self.request)
        except:
            workloads = []
            msg = _('Workloads list can not be retrieved.')
            exceptions.handle(self.request, msg)
        return workloads
    
    def get_workload_types_data(self):
        try:
            workload_types = workloadmgr.workload_type_list(self.request)
        except:
            workload_types = []
            msg = _('WorkloadTypes list can not be retrieved.')
            exceptions.handle(self.request, msg)
        return workload_types   
        
class CreateView(workflows.WorkflowView):
    workflow_class = CreateWorkload
    template_name = 'project/workloads/create.html'

    def get_initial(self):
        pass


class DetailView(tables.DataTableView):
    table_class = SnapshotsTable
    template_name = 'project/workloads/detail.html'
    failure_url = reverse_lazy('horizon:project:workloads:index')

    def get_data(self):
        try:
            workload = self._get_data()
            snapshots = workloadmgr.snapshot_list(self.request,
                                              workload_id=workload.id)
        except:
            snapshots = []
            msg = _('Snapshots list can not be retrieved.')
            exceptions.handle(self.request, msg)
        return snapshots
        
    def _get_data(self):
        if not hasattr(self, "_workload"):
            try:
                workload_id = self.kwargs['workload_id']
                workload = workloadmgr.workload_get(self.request, workload_id)
            except:
                msg = _('Unable to retrieve details for workload "%s".') \
                      % (workload_id)
                exceptions.handle(self.request, msg, redirect=self.failure_url)
            self._workload = workload
        return self._workload

    def get_context_data(self, **kwargs):
        context = super(DetailView, self).get_context_data(**kwargs)
        context["workload"] = self._get_data()
        return context
