# Copyright (c) 2014 TrilioData, Inc.
# All Rights Reserved.

from __future__ import print_function

import argparse
import os
import sys
import time
import ast

from workloadmgrclient import exceptions
from workloadmgrclient import utils
from workloadmgrclient.openstack.common import strutils


def _poll_for_status(poll_fn, obj_id, action, final_ok_states,
                     poll_period=5, show_progress=True):
    """Block while an action is being performed, periodically printing
    progress.
    """
    def print_progress(progress):
        if show_progress:
            msg = ('\rInstance %(action)s... %(progress)s%% complete'
                   % dict(action=action, progress=progress))
        else:
            msg = '\rInstance %(action)s...' % dict(action=action)

        sys.stdout.write(msg)
        sys.stdout.flush()

    print()
    while True:
        obj = poll_fn(obj_id)
        status = obj.status.lower()
        progress = getattr(obj, 'progress', None) or 0
        if status in final_ok_states:
            print_progress(100)
            print("\nFinished")
            break
        elif status == "error":
            print("\nError %(action)s instance" % locals())
            break
        else:
            print_progress(progress)
            time.sleep(poll_period)
            
def _find_workload_type(cs, workload_type_id):
    """Get a workload by ID."""
    return utils.find_resource(cs.workload_types, workload_type_id)            

def _find_workload(cs, workload_id):
    """Get a workload by ID."""
    return utils.find_resource(cs.workloads, workload_id)

def _find_snapshot(cs, snapshot_id):
    """Get a workload snapshot by ID."""
    return utils.find_resource(cs.snapshots, snapshot_id)

def _find_restore(cs, restore_id):
    """Get a workload snapshot restore by ID."""
    return utils.find_resource(cs.restores, restore_id)

def _find_testbubble(cs, testbubble_id):
    """Get a workload snapshot testbubble by ID."""
    return utils.find_resource(cs.testbubbles, testbubble_id)
    
def _translate_keys(collection, convert):
    for item in collection:
        keys = item.__dict__.keys()
        for from_key, to_key in convert:
            if from_key in keys and to_key not in keys:
                setattr(item, to_key, item._info[from_key])

def _translate_workload_snapshot_keys(collection):
    convert = [('workloadId', 'workload_Id')]
    _translate_keys(collection, convert)


def _extract_metadata(args):
    metadata = {}
    for metadatum in args.metadata:
        # unset doesn't require a val, so we have the if/else
        if '=' in metadatum:
            (key, value) = metadatum.split('=', 1)
        else:
            key = metadatum
            value = None

        metadata[key] = value
    return metadata


def _print_type_and_extra_specs_list(vtypes):
    formatters = {'extra_specs': _print_type_extra_specs}
    utils.print_list(vtypes, ['ID', 'Name', 'extra_specs'], formatters)


def do_endpoints(cs, args):
    """Discover endpoints that get returned from the authenticate services."""
    catalog = cs.client.service_catalog.catalog
    for e in catalog['access']['serviceCatalog']:
        utils.print_dict(e['endpoints'][0], e['name'])


def do_credentials(cs, args):
    """Show user credentials returned from auth."""
    catalog = cs.client.service_catalog.catalog
    utils.print_dict(catalog['access']['user'], "User Credentials")
    utils.print_dict(catalog['access']['token'], "Token")

_quota_resources = ['volumes', 'snapshots', 'gigabytes']


def _print_type_extra_specs(vol_type):
    try:
        return vol_type.get_keys()
    except exceptions.NotFound:
        return "N/A"

@utils.arg('--metadata',
     metavar="<key=vaule>",
     action='append',
     dest='metadata',
     default=[],
     help=  "Specify a key vaule pairs to include in the workload_type metadata "
            "Specify option multiple times to include multiple keys. "
            "key:vaule")
@utils.arg('--display-name', metavar='<display-name>',
           help='Optional workload_type name. (Default=None)',
           default=None)
@utils.arg('--is-public',
           type=strutils.bool_from_string, metavar='{True,False}',
           help='Make image accessible to the public.',
           default=False)
@utils.arg('--display-description', metavar='<display-description>',
           help='Optional workload_type description. (Default=None)',
           default=None)
@utils.service_type('workloads')
def do_workload_type_create(cs, args):
    """Creates a workload_type."""
    metadata = {}
    for metadata_str in args.metadata:
        err_msg = ("Invalid metadata argument '%s'. metadata arguments must be of the "
                   "form --metadata <key=value>" % metadata_str)

        for kv_str in metadata_str.split(","):
            try:
                k, v = kv_str.split("=", 1)
            except ValueError as e:
                raise exceptions.CommandError(err_msg)

            if k in metadata:
                metadata[k] = v
            else:
                metadata.setdefault(k, v)

   
    cs.workload_types.create(metadata,
                             args.display_name,
                             args.display_description,
                             args.is_public)

@utils.arg('workload_type_id', metavar='<workload_type_id>', help='ID of the workload_type.')
@utils.arg('--metadata',
     metavar="<key=vaule>",
     action='append',
     dest='metadata',
     default=[],
     help=  "Specify a key vaule pairs to include in the workload_type metadata "
            "Specify option multiple times to include multiple keys. "
            "key:vaule")
@utils.service_type('workloads')
def do_workload_type_discover_instances(cs, args):
    """Discover instances of a workload_type."""
    metadata = {}
    for metadata_str in args.metadata:
        err_msg = ("Invalid metadata argument '%s'. metadata arguments must be of the "
                   "form --metadata <key=value>" % metadata_str)

        for kv_str in metadata_str.split(","):
            try:
                k, v = kv_str.split("=", 1)
            except ValueError as e:
                raise exceptions.CommandError(err_msg)

            if k in metadata:
                metadata[k] = v
            else:
                metadata.setdefault(k, v)
    
    instances = cs.workload_types.discover_instances(args.workload_type_id, metadata)
    utils.print_dict(instances, wrap=100)
    
@utils.arg('workload_type_id', metavar='<workload_type_id>', help='ID of the workload_type.')
@utils.service_type('workloads')
def do_workload_type_show(cs, args):
    """Show details about a workload_type."""
    workload_type = _find_workload_type(cs, args.workload_type_id)
    info = dict()
    info.update(workload_type._info)

    if 'links' in info:
        info.pop('links')

    utils.print_dict(info, wrap=100)


@utils.service_type('workloads')
def do_workload_type_list(cs, args):
    """List all the workload_type."""
    workload_types = cs.workload_types.list()
    columns = ['ID', 'Name']
    utils.print_list(workload_types, columns)


@utils.arg('workload_type_id', metavar='<workload_type_id>',
           help='ID of the workload_type to delete.')
@utils.service_type('workloads')
def do_workload_type_delete(cs, args):
    """Remove a workload."""
    workload_type = _find_workload_type(cs, args.workload_type_id)
    workload_type.delete()


@utils.arg('--display-name', metavar='<display-name>',
           help='Optional workload name. (Default=None)',
           default=None)
@utils.arg('--display-description', metavar='<display-description>',
           help='Optional workload description. (Default=None)',
           default=None)
@utils.arg('--workload-type-id', metavar='<workload-type-id>',
           help='Workload Type ID is required',
           required=True)
@utils.arg('--instance',
     metavar="<instance-id=instance-uuid>",
     action='append',
     dest='instances',
     default=[],
     help="Specify an instance to include in the workload. "
           "Specify option multiple times to include multiple instances. "
           "instance-id: include the instance with this UUID ")
@utils.arg('--jobschedule',
     metavar="<key=key-name>",
     action='append',
     dest='jobschedule',
     default=[],
     help=  "Specify following key vaule pairs for jobschedule "
            "Specify option multiple times to include multiple keys. "
            " 'start_date' : '06/05/2014' "
            " 'end_date' : '07/15/2014' "
            " 'start_time' : '2:30 PM' "
            " 'interval' : '1 hr' "
            " 'snapshots_to_retain' : '2' ")
@utils.arg('--metadata',
     metavar="<key=key-name>",
     action='append',
     dest='metadata',
     default=[],
     help=  "Specify a key vaule pairs to include in the workload_type metadata "
            "Specify option multiple times to include multiple keys. "
            "key: vaule")
@utils.service_type('workloads')
def do_workload_create(cs, args):
    """Creates a workload."""

    instances = []
    for instance_str in args.instances:
        err_msg = ("Invalid instance argument '%s'. Instance arguments must be of the "
                   "form --instance <instance-id=instance-uuid>" % instance_str)
        instance_info = {"instance-id": ""}

        for kv_str in instance_str.split(","):
            try:
                k, v = kv_str.split("=", 1)
            except ValueError as e:
                raise exceptions.CommandError(err_msg)

            if k in instance_info:
                instance_info[k] = v
            else:
                raise exceptions.CommandError(err_msg)

        if not instance_info['instance-id']:
            raise exceptions.CommandError(err_msg)

        instances.append(instance_info)
        
    jobschedule = {}
    for jobschedule_str in args.jobschedule:
        err_msg = ("Invalid jobschedule argument '%s'. jobschedule arguments must be of the "
                   "form --jobschedule <key=value>" % jobschedule_str)

        for kv_str in jobschedule_str.split(","):
            try:
                k, v = kv_str.split("=", 1)
            except ValueError as e:
                raise exceptions.CommandError(err_msg)

            if k in jobschedule:
                jobschedule[k] = v
            else:
                jobschedule.setdefault(k, v)     
                
    metadata = {}
    for metadata_str in args.metadata:
        err_msg = ("Invalid metadata argument '%s'. metadata arguments must be of the "
                   "form --metadata <key=value>" % metadata_str)

        for kv_str in metadata_str.split(","):
            try:
                k, v = kv_str.split("=", 1)
            except ValueError as e:
                raise exceptions.CommandError(err_msg)

            if k in metadata:
                metadata[k] = v
            else:
                metadata.setdefault(k, v)  
    
    cs.workloads.create(args.display_name,
                        args.display_description,
                        args.workload_type_id,
                        instances,
                        jobschedule,
                        metadata)

@utils.arg('workload_id', metavar='<workload_id>', help='ID of the workload.')
@utils.arg('--display-name', metavar='<display-name>',
           help='Optional workload name. (Default=None)',
           default=None)
@utils.arg('--display-description', metavar='<display-description>',
           help='Optional workload description. (Default=None)',
           default=None)
@utils.arg('--instance',
     metavar="<instance-id=instance-uuid>",
     action='append',
     dest='instances',
     default=[],
     help="Specify an instance to include in the workload. "
           "Specify option multiple times to include multiple instances. "
           "instance-id: include the instance with this UUID ")
@utils.arg('--jobschedule',
     metavar="<key=key-name>",
     action='append',
     dest='jobschedule',
     default=[],
     help=  "Specify following key vaule pairs for jobschedule "
            "Specify option multiple times to include multiple keys. "
            " 'start_date' : '06/05/2014' "
            " 'end_date' : '07/15/2014' "
            " 'start_time' : '2:30 PM' "
            " 'interval' : '1 hr' "
            " 'snapshots_to_retain' : '2' ")
@utils.arg('--metadata',
     metavar="<key=key-name>",
     action='append',
     dest='metadata',
     default=[],
     help=  "Specify a key vaule pairs to include in the workload_type metadata "
            "Specify option multiple times to include multiple keys. "
            "key: vaule")
@utils.service_type('workloads')
def do_workload_modify(cs, args):
    """Modify a workload."""

    workload = _find_workload(cs, args.workload_id)
    
    instances = []
    for instance_str in args.instances:
        err_msg = ("Invalid instance argument '%s'. Instance arguments must be of the "
                   "form --instance <instance-id=instance-uuid>" % instance_str)
        instance_info = {"instance-id": ""}

        for kv_str in instance_str.split(","):
            try:
                k, v = kv_str.split("=", 1)
            except ValueError as e:
                raise exceptions.CommandError(err_msg)

            if k in instance_info:
                instance_info[k] = v
            else:
                raise exceptions.CommandError(err_msg)

        if not instance_info['instance-id']:
            raise exceptions.CommandError(err_msg)

        instances.append(instance_info)
        
    jobschedule = {}
    for jobschedule_str in args.jobschedule:
        err_msg = ("Invalid jobschedule argument '%s'. jobschedule arguments must be of the "
                   "form --jobschedule <key=value>" % jobschedule_str)

        for kv_str in jobschedule_str.split(","):
            try:
                k, v = kv_str.split("=", 1)
            except ValueError as e:
                raise exceptions.CommandError(err_msg)

            if k in jobschedule:
                jobschedule[k] = v
            else:
                jobschedule.setdefault(k, v)     
                
    metadata = {}
    for metadata_str in args.metadata:
        err_msg = ("Invalid metadata argument '%s'. metadata arguments must be of the "
                   "form --metadata <key=value>" % metadata_str)

        for kv_str in metadata_str.split(","):
            try:
                k, v = kv_str.split("=", 1)
            except ValueError as e:
                raise exceptions.CommandError(err_msg)

            if k in metadata:
                metadata[k] = v
            else:
                metadata.setdefault(k, v)  
                
                
    
    workload.update(args.workload_id,
                    args.display_name,
                    args.display_description,
                    args.workload_type_id,
                    instances,
                    jobschedule,
                    metadata)


@utils.arg('workload_id', metavar='<workload_id>', help='ID of the workload.')
@utils.service_type('workloads')
def do_workload_show(cs, args):
    """Show details about a workload."""
    workload = _find_workload(cs, args.workload_id)
    info = dict()
    info.update(workload._info)

    if 'links' in info:
        info.pop('links')

    utils.print_dict(info, wrap=100)
    
@utils.arg('workload_id', metavar='<workload_id>', help='ID of the workload.')
@utils.service_type('workloads')
def do_workload_get_workflow(cs, args):
    """Show details about a workload."""
    workflow = cs.workloads.get_workflow(args.workload_id)
    utils.print_dict(workflow, wrap=100)    

@utils.arg('workload_id', metavar='<workload_id>', help='ID of the workload.')
@utils.service_type('workloads')
def do_workload_get_topology(cs, args):
    """Show details about a workload."""
    topology = cs.workloads.get_topology(args.workload_id)
    utils.print_dict(topology, wrap=100)

@utils.service_type('workloads')
def do_workload_list(cs, args):
    """List all the workloads."""
    workloads = cs.workloads.list()
    columns = ['ID', 'Name', 'Workload_Type_ID']
    utils.print_list(workloads, columns)


@utils.arg('workload_id', metavar='<workload_id>',
           help='ID of the workload to delete.')
@utils.service_type('workloads')
def do_workload_delete(cs, args):
    """Remove a workload."""
    workload = _find_workload(cs, args.workload_id)
    workload.delete()

@utils.arg('workload_id', metavar='<workload_id>',
           help='ID of the workload to snapshot.')
@utils.arg('--full',
    dest='full',
    action="store_true",
    default=False,
    help='Specify if a full snapshot is required.')
@utils.arg('--display-name', metavar='<display-name>',
           help='Optional snapshot name. (Default=None)',
           default=None)
@utils.arg('--display-description', metavar='<display-description>',
           help='Optional snapshot description. (Default=None)',
           default=None)
@utils.service_type('workloads')
def do_workload_snapshot(cs, args):
    """Snapshots a workload."""
    workload = _find_workload(cs, args.workload_id)
    workload.snapshot(args.full, args.display_name, args.display_description)
    
    
@utils.arg('workload_id', metavar='<workload_id>',
           help='ID of the workload to pause.')
@utils.service_type('workloads')
def do_workload_pause(cs, args):
    """pauses a workload."""
    workload = _find_workload(cs, args.workload_id)
    workload.pause() 
    
@utils.arg('workload_id', metavar='<workload_id>',
           help='ID of the workload to resume.')
@utils.service_type('workloads')
def do_workload_resume(cs, args):
    """resumes a workload."""
    workload = _find_workload(cs, args.workload_id)
    workload.resume()        

@utils.arg('snapshot_id', metavar='<snapshot_id>', help='ID of the workload snapshot.')
@utils.service_type('workloads')
def do_snapshot_show(cs, args):
    """Show details about a workload snapshot"""
    snapshot = _find_snapshot(cs, args.snapshot_id)
    info = dict()
    info.update(snapshot._info)

    if 'links' in info:
        info.pop('links')

    utils.print_dict(info)

@utils.arg('--workload_id',
           metavar='<workload_id>',
           default=None,
           help='Filter results by workload_id')
@utils.service_type('workloads')
def do_snapshot_list(cs, args):
    """List all the workloads."""

    search_opts = {
        'workload_id': args.workload_id,
    }
    snapshots = cs.snapshots.list(search_opts=search_opts)
    columns = ['ID', 'Workload ID', 'Snapshot Type','Status']
    utils.print_list(snapshots, columns)


@utils.arg('snapshot_id', metavar='<snapshot_id>',
           help='ID of the workload snapshot to delete.')
@utils.service_type('workloads')
def do_snapshot_delete(cs, args):
    """Remove a workload snapshot."""
    snapshot = _find_snapshot(cs, args.snapshot_id)
    snapshot.delete()
    
@utils.arg('snapshot_id', metavar='<snapshot_id>',
           help='ID of the workload snapshot to restore.')
@utils.arg('--test',
    dest='test',
    action="store_true",
    default=False,
    help='Specify if testing of a restore is required')
@utils.arg('--display-name', metavar='<display-name>',
           help='Optional name for the restore. (Default=None)',
           default=None)
@utils.arg('--display-description', metavar='<display-description>',
           help='Optional description for restore. (Default=None)',
           default=None)
@utils.arg('--options', metavar='<options>',
           help='Restore options. (Default={})',
           default='{}')            
@utils.service_type('workloads')
def do_snapshot_restore(cs, args):
    """Restore a workload snapshot."""
    snapshot = _find_snapshot(cs, args.snapshot_id)
    options = ast.literal_eval(args.options)
    snapshot.restore(args.test, args.display_name, args.display_description, options)
    
@utils.arg('restore_id', metavar='<restore_id>', help='ID of the restore.')
@utils.service_type('workloads')
def do_restore_show(cs, args):
    """Show details about a workload snapshot restore"""
    restore = _find_restore(cs, args.restore_id)
    info = dict()
    info.update(restore._info)

    if 'links' in info:
        info.pop('links')

    utils.print_dict(info, wrap=100)

@utils.arg('--snapshot_id',
           metavar='<snapshot_id>',
           default=None,
           help='Filter results by snapshot_id')
@utils.service_type('workloads')
def do_restore_list(cs, args):
    """List all the restores."""

    search_opts = {
        'snapshot_id': args.snapshot_id,
    }
    restores = cs.restores.list(search_opts=search_opts)
    columns = ['ID', 'Snapshot ID', 'Status']
    utils.print_list(restores, columns)


@utils.arg('restore_id', metavar='<restores_id>',
           help='ID of the restore to delete.')
@utils.service_type('workloads')
def do_restore_delete(cs, args):
    """Delete a restore."""
    restore = _find_restore(cs, args.restore_id)
    restore.delete()
    

@utils.arg('testbubble_id', metavar='<testbubble_id>', help='ID of the testbubble.')
@utils.service_type('workloads')
def do_testbubble_show(cs, args):
    """Show details about a workload snapshot testbubble"""
    testbubble = _find_testbubble(cs, args.testbubble_id)
    info = dict()
    info.update(testbubble._info)

    if 'links' in info:
        info.pop('links')

    utils.print_dict(info, wrap=100)

@utils.arg('--snapshot_id',
           metavar='<snapshot_id>',
           default=None,
           help='Filter results by snapshot_id')
@utils.service_type('workloads')
def do_testbubble_list(cs, args):
    """List all the testbubbles."""

    search_opts = {
        'snapshot_id': args.snapshot_id,
    }
    testbubbles = cs.testbubbles.list(search_opts=search_opts)
    columns = ['ID', 'Snapshot ID', 'Status']
    utils.print_list(testbubbles, columns)


@utils.arg('testbubble_id', metavar='<testbubbles_id>',
           help='ID of the testbubble to delete.')
@utils.service_type('workloads')
def do_testbubble_delete(cs, args):
    """Delete a testbubble."""
    testbubble = _find_testbubble(cs, args.testbubble_id)
    testbubble.delete()
       
