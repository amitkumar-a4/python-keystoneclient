# Copyright (c) 2013 TrilioData, Inc.
"""
WorkloadTypes Interface (1.1 extension).
"""
from workloadmgrclient import base


class WorkloadType(base.Resource):
    """A workload_type describes the type of a workload"""
    def __repr__(self):
        return "<WorkloadType: %s>" % self.id

    def delete(self):
        """Delete this workload_type."""
        return self.manager.delete(self)


class WorkloadTypesManager(base.ManagerWithFind):
    """Manage :class:`WorkloadType` resources."""
    resource_class = WorkloadType

    def create(self, metadata=None, name=None, description=None, is_public=False):
        """Create a workload_type.

        :param metadata: metadata of workload_type.
        :param name: The name of the workload_type.
        :param description: The description of the workload_type.
        :rtype: :class:`WorkloadType`
        """
        body = {'workload_type': {'metadata': metadata,
                                  'name': name,
                                  'description': description,
                                  'is_public': is_public, }}
        return self._create('/workload_types', body, 'workload_type')

    def get(self, workload_type_id):
        """Show details of a workload_type.

        :param workload_type_id: The ID of the workload_type to display.
        :rtype: :class:`WorkloadType`
        """
        return self._get("/workload_types/%s" % workload_type_id, "workload_type")

    def list(self, detailed=True):
        """Get a list of all workload_types.

        :rtype: list of :class:`WorkloadType`
        """
        if detailed is True:
            return self._list("/workload_types/detail", "workload_types")
        else:
            return self._list("/workload_types", "workload_types")

    def delete(self, workload_type_id):
        """Delete a workload_type.

        :param workload_type_id: The :class:`WorkloadType` to delete.
        """
        self._delete("/workload_types/%s" % base.getid(workload_type_id))
        
    def discover_instances(self, workload_type_id, metadata=None):
        """Discover instances of a workload_type.

        :param metadata: metadata of workload_type.
        :rtype: instances
        """
        body = {'metadata': metadata}
        instances =  self._discover_instances("/workload_types/%s/discover_instances" % workload_type_id, body)
        return instances        

     
        
