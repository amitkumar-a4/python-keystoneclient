# Copyright 2014 TrilioData Inc.
# All Rights Reserved.

"""
An extension module for novaclient that allows the `nova` application access to
the contego API extensions.
"""

import os
import base64
import re
import json
import sys


from novaclient import utils
from novaclient import base
from novaclient import exceptions
from novaclient.v1_1 import servers


import http

# Add new client capabilities here. Each key is a capability name and its value
# is the list of API capabilities upon which it depends.

CAPABILITIES = {}

CAPS_HELP = {}

def __pre_parse_args__():
    pass

def __post_parse_args__(args):
    pass

def _find_server(cs, server):
    """ Returns a server by name or ID. """
    return utils.find_resource(cs.contego, server)

def inherit_args(inherit_from_fn):
    """Decorator to inherit all of the utils.arg decorated agruments from
    another function.
    """
    def do_inherit(fn):
        if hasattr(inherit_from_fn, 'arguments'):
            fn.arguments = inherit_from_fn.arguments
        return fn
    return do_inherit

#### ACTIONS ####
@utils.arg('server', metavar='<instance>', help="Name or ID of server.")
def do_vast_instance(cs, args):
    """VAST a running instance."""
    server = _find_server(cs, args.server)
    cs.contego.vast_instance(server, {})

@utils.arg('--all', dest='all', action='store_true', default=False,
           help='List all capabilities, enabled or not.')
def do_contego_capabilities(cs, args):
    """Display Contego capabilities supported by the API."""
    caps = dict(CAPS_HELP)
    # Watch out for sloppiness
    for k in [ x for x in CAPABILITIES.keys() if x not in CAPS_HELP ]:
        caps[k] = ''
    if not args.all:
        if not hasattr(cs.contego, 'capabilities'):
            cs.contego.setup_capabilities()
        elide = list(set(CAPABILITIES.keys()) - set(cs.contego.capabilities))
        for k in elide:
            del(caps[k])
    for cap, help in caps.items():
        print'    %-20s  %s' % (cap, help)

class ContegoServer(servers.Server):
    """
    A server object extended to provide contego capabilities
    """
    def vast_instance(self):
        #return self.manager.vast_snapshot()
        pass

class ContegoServerManager(servers.ServerManager):
    resource_class = ContegoServer

    def __init__(self, client, *args, **kwargs):
        servers.ServerManager.__init__(self, client, *args, **kwargs)

        # Make sure this instance is available as contego.
        if not(hasattr(client, 'contego')):
            setattr(client, 'contego', self)

    # Capabilities must be computed lazily because self.api.client isn't
    # available in __init__

    def setup_capabilities(self):
        api_caps = self.get_info()['capabilities']
        self.capabilities = [cap for cap in CAPABILITIES.keys() if \
                all([api_req in api_caps for api_req in CAPABILITIES[cap]])]

    def satisfies(self, requirements):
        if not hasattr(self, 'capabilities'):
            self.setup_capabilities()

        return set(requirements) <= set(self.capabilities)

    def get_info(self):
        url = '/contegoinfo'
        res = self.api.client.get(url)[1]
        return res

    def vast_prepare(self, server, params):
        header, info = self._action("contego_vast_prepare", base.getid(server), params)
        return info 
    
    def vast_freeze(self, server, params):
        header, info = self._action("contego_vast_freeze", base.getid(server), params)
        return info 
    
    def vast_thaw(self, server, params):
        header, info = self._action("contego_vast_thaw", base.getid(server), params)
        return info 
        
    def vast_instance(self, server, params):
        header, info = self._action("contego_vast_instance", base.getid(server), params)
        return info
    
    def vast_get_info(self, server, params):
        header, info = self._action("contego_vast_get_info", base.getid(server), params)
        return info    

    def vast_data_url(self, server, params):
        header, info = self._action("contego_vast_data_url", base.getid(server), params)
        return info    
    
    def vast_data(self, server, params, do_checksum = True):
        
        #management_urls = self.vast_data_url(server, {})['urls']
        management_urls = params['urls']
        #TODO(giri): implement https
        try: 
            http_client = http.HTTPClient(self.api.client, management_urls[0])
            resp, body = http_client.raw_request('GET', '')
        except Exception as err:
            if len(management_urls) > 1:
                http_client = http.HTTPClient(self.api.client, management_urls[1])
                resp, body = http_client.raw_request('GET', '')
                        
        checksum = resp.getheader('content-md5', None)
        if do_checksum and checksum is not None:
            body.set_checksum(checksum)        
        return body 
    
    def vast_finalize(self, server, params):
        header, info = self._action("contego_vast_finalize", base.getid(server), params)
        return info             
       
    def testbubble_attach_volume(self, server, params):
        header, info = self._action("contego_testbubble_attach_volume", base.getid(server), params)
        return info
    
    def testbubble_reboot_instance(self, server, params):
        header, info = self._action("contego_testbubble_reboot_instance", base.getid(server), params)
        return info               
                   

