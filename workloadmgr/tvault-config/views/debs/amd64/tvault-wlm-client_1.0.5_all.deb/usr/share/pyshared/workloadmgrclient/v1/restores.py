# Copyright (c) 2014 TrilioData, Inc.
# All Rights Reserved.

"""
Restores interface (1.1 extension).
"""

import six
try:
    from urllib import urlencode
except ImportError:
    from urllib.parse import urlencode
    
from workloadmgrclient import base


class Restore(base.Resource):
    """A snapshot restore either test or production"""
    def __repr__(self):
        return "<Restore: %s>" % self.id

    def delete(self):
        """Delete this restore."""
        return self.manager.delete(self)

class RestoresManager(base.ManagerWithFind):
    """Manage :class:`Restore` resources."""
    resource_class = Restore


    def get(self, restore_id):
        """Show details of a snapshot restore.

        :param restore_id: The ID of the snapshot restore to display.
        :rtype: :class:`Restore`
        """
        return self._get("/restores/%s" % restore_id, "restore")

    def list(self, detailed=True, search_opts=None):
        """Get a list of all snapshot restores

        :rtype: list of :class:`Restore`
        """
        if search_opts is None:
            search_opts = {}   
            
        qparams = {}

        for opt, val in six.iteritems(search_opts):
            if val:
                qparams[opt] = val

        query_string = "?%s" % urlencode(qparams) if qparams else ""

        detail = ""
        if detailed:
            detail = "/detail"
        
        return self._list("/restores%s%s" % (detail, query_string),
                          "restores")
                          
    def delete(self, restore_id):
        """Delete a snapshot restore.

        :param restore_id: The :class:`Restore` to delete.
        """
        self._delete("/restores/%s" % base.getid(restore_id))

