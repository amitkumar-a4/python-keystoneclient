# vim: tabstop=4 shiftwidth=4 softtabstop=4

# Copyright (c) 2013 TrilioData, Inc.


import logging

from django.core.urlresolvers import reverse, reverse_lazy
from django.utils.translation import ugettext_lazy as _

from horizon import exceptions
from horizon import tables

from openstack_dashboard import api
from workloads import workloadmgr

LOG = logging.getLogger(__name__)

class Delete(tables.DeleteAction):
    data_type_singular = _("Restore")
    data_type_plural = _("Restores")

    def delete(self, request, obj_id):
        try:
            workloadmgr.restore_delete(request, obj_id)
        except:
            msg = _('Failed to delete restore %s') % obj_id
            LOG.info(msg)
            redirect = reverse('horizon:project:workloads:snapshots:detail',args=[obj_id])
            exceptions.handle(request, msg, redirect=redirect)

class UpdateRow(tables.Row):
    ajax = True
    def get_data(self, request, restore_id):
        restore = workloadmgr.restore_get(request, restore_id)
        return restore


class RestoresTable(tables.DataTable):
    time_stamp = tables.Column("created_at", verbose_name=_("Time Stamp")) 
    id = tables.Column("id", verbose_name=_("ID"))
    status = tables.Column("status", verbose_name=_("Status"))                         
    failure_url = reverse_lazy('horizon:project:workloads:snapshots:detail')

    class Meta:
        name = "restores"
        verbose_name = _("Restores")
        row_class = UpdateRow
        table_actions = (Delete,)
        row_actions = (Delete,)
