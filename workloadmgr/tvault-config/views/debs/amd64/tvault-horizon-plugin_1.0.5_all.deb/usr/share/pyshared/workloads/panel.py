# Copyright (c) 2014 TrilioData, Inc.
# All Rights Reserved..

from django.utils.translation import ugettext_lazy as _

import horizon

from openstack_dashboard.dashboards.project import dashboard


class Workloads(horizon.Panel):
    name = _("Workloads")
    slug = 'workloads'
    permissions = ('openstack.services.workloads',)

dashboard.Project.register(Workloads)
