# vim: tabstop=4 shiftwidth=4 softtabstop=4

# Copyright (c) 2013 TrilioData, Inc.

from django.conf.urls.defaults import patterns, url

from .views import DetailView


RESTORES = r'^(?P<restore_id>[^/]+)/%s$'
VIEW_MOD = 'openstack_dashboard.dashboards.project.workloads.snapshots.restores.views'


urlpatterns = patterns(VIEW_MOD,
    url(RESTORES % 'detail', DetailView.as_view(), name='detail')
)
