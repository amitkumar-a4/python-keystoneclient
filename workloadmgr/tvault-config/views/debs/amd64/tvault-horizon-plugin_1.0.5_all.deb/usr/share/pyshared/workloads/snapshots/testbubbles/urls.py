# vim: tabstop=4 shiftwidth=4 softtabstop=4

# Copyright (c) 2013 TrilioData, Inc.

from django.conf.urls.defaults import patterns, url

from .views import DetailView


TESTBUBBLES = r'^(?P<testbubble_id>[^/]+)/%s$'
VIEW_MOD = 'openstack_dashboard.dashboards.project.workloads.snapshots.testbubbles.views'


urlpatterns = patterns(VIEW_MOD,
    url(TESTBUBBLES % 'detail', DetailView.as_view(), name='detail')
)
