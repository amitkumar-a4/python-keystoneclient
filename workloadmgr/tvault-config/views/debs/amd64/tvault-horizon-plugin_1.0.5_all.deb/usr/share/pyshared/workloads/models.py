# vim: tabstop=4 shiftwidth=4 softtabstop=4

# Copyright 2014 TrilioData Inc.
# All Rights Reserved.

"""
Stub file to work around django bug: https://code.djangoproject.com/ticket/7198
"""
