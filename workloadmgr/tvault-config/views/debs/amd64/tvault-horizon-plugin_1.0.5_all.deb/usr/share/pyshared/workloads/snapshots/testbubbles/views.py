# vim: tabstop=4 shiftwidth=4 softtabstop=4
# Copyright (c) 2013 TrilioData, Inc.

"""
Views for managing Quantum Snapshots.
"""
import logging

from django.core.urlresolvers import reverse_lazy, reverse
from django.utils.translation import ugettext_lazy as _

from horizon import exceptions
from horizon import tabs
from horizon import workflows

from openstack_dashboard import api
from .tabs import TestbubbleDetailTabs


LOG = logging.getLogger(__name__)


class DetailView(tabs.TabView):
    tab_group_class = TestbubbleDetailTabs
    template_name = 'project/workloads/snapshots/testbubbles/detail.html'
