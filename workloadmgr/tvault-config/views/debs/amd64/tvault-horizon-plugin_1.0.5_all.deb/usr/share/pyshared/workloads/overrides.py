from django.utils.translation import ugettext_lazy as _

import horizon
import panel

