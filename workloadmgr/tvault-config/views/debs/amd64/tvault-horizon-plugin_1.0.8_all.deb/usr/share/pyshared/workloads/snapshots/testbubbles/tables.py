# vim: tabstop=4 shiftwidth=4 softtabstop=4

# Copyright (c) 2013 TrilioData, Inc.


import logging

from django.core.urlresolvers import reverse, reverse_lazy
from django.utils.translation import ugettext_lazy as _

from horizon import exceptions
from horizon import tables

from openstack_dashboard import api
from workloads import workloadmgr

LOG = logging.getLogger(__name__)

class Delete(tables.DeleteAction):
    data_type_singular = _("Testbubble")
    data_type_plural = _("Testbubbles")

    def delete(self, request, obj_id):
        try:
            workloadmgr.testbubble_delete(request, obj_id)
        except:
            msg = _('Failed to delete testbubble %s') % obj_id
            LOG.info(msg)
            redirect = reverse('horizon:project:workloads:snapshots:detail',args=[obj_id])
            exceptions.handle(request, msg, redirect=redirect)

class UpdateRow(tables.Row):
    ajax = True
    def get_data(self, request, testbubble_id):
        testbubble = workloadmgr.testbubble_get(request, testbubble_id)
        return testbubble


class TestbubblesTable(tables.DataTable):
    time_stamp = tables.Column("created_at", verbose_name=_("Time Stamp")) 
    id = tables.Column("id", verbose_name=_("ID"))
    status = tables.Column("status", verbose_name=_("Status"))                         
    failure_url = reverse_lazy('horizon:project:workloads:snapshots:detail')

    class Meta:
        name = "testbubbles"
        verbose_name = _("Testbubbles")
        row_class = UpdateRow
        table_actions = (Delete,)
        row_actions = (Delete,)
