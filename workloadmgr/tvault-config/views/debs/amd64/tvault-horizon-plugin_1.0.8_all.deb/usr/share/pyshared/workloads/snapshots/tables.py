# Copyright (c) 2014 TrilioData, Inc.
# All Rights Reserved.

import logging

from django.core.urlresolvers import reverse, reverse_lazy
from django.utils.translation import ugettext_lazy as _

from horizon import exceptions
from horizon import tables

from openstack_dashboard import api
from workloads import workloadmgr

LOG = logging.getLogger(__name__)

class RestoreSnapshot(tables.BatchAction):
    name = "Restore"
    verbose_name = _("Restore")
    action_present = _("Restore")
    action_past = _("Scheduled restore of")
    classes = ("btn-simple", "btn-restore")
    data_type_singular = _("Snapshot")
    data_type_plural = _("Snapshots")

      
    def action(self, request, obj_id):
        try:
            workloadmgr.snapshot_restore(request, obj_id, test=False)
        except:
            msg = _('Failed to restore snapshot %s') % obj_id
            LOG.info(msg)
            redirect = reverse('horizon:project:workloads:snapshots:detail',args=[obj_id])
            exceptions.handle(request, msg, redirect=redirect)
            
class TestSnapshot(tables.BatchAction):
    name = "Test"
    verbose_name = _("Test")
    action_present = _("Test")
    action_past = _("Scheduled test of")
    classes = ("btn-simple", "btn-testrestore")
    data_type_singular = _("Snapshot")
    data_type_plural = _("Snapshots")

      
    def action(self, request, obj_id):
        try:
            workloadmgr.snapshot_restore(request, obj_id, test=True)
        except:
            msg = _('Failed to test snapshot %s') % obj_id
            LOG.info(msg)
            redirect = reverse('horizon:project:workloads:snapshots:detail',args=[obj_id])
            exceptions.handle(request, msg, redirect=redirect)            

class DeleteSnapshot(tables.DeleteAction):
    data_type_singular = _("Snapshot")
    data_type_plural = _("Snapshots")

    def delete(self, request, obj_id):
        try:
            workloadmgr.snapshot_delete(request, obj_id)
        except:
            msg = _('Failed to delete snapshot %s') % obj_id
            LOG.info(msg)
            redirect = reverse('horizon:project:workloads:snapshots:detail',args=[obj_id])
            exceptions.handle(request, msg, redirect=redirect)

class UpdateRow(tables.Row):
    ajax = True
    def get_data(self, request, snapshot_id):
        snapshot = workloadmgr.snapshot_get(request, snapshot_id)
        return snapshot


class SnapshotsTable(tables.DataTable):
    time_stamp = tables.Column("created_at", verbose_name=_("Time Stamp")) 
    id = tables.Column("id", verbose_name=_("ID"), 
                         link='horizon:project:workloads:snapshots:detail')
    type = tables.Column("snapshot_type", verbose_name=_("Type"))                      
    status = tables.Column("status", verbose_name=_("Status"))                         
    failure_url = reverse_lazy('horizon:project:workloads:index')

    class Meta:
        name = "snapshots"
        verbose_name = _("Snapshots")
        row_class = UpdateRow
        table_actions = (DeleteSnapshot,)
        row_actions = (RestoreSnapshot,TestSnapshot,DeleteSnapshot)
