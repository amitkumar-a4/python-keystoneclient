# Copyright (c) 2014 TrilioData, Inc.
# All Rights Reserved.

import logging

from django import template
from django.core.urlresolvers import reverse
from django.template import defaultfilters as filters
from django.utils.translation import ugettext_lazy as _
from django.utils import http

from horizon import exceptions
from horizon import tables

from openstack_dashboard import api
from workloads import workloadmgr

LOG = logging.getLogger(__name__)

class WorkloadSnapshotFull(tables.BatchAction):
    name = "Full Snapshot"
    verbose_name = _("Full Snapshot")
    action_present = _("Full Snapshot")
    action_past = _("Scheduled execution of")
    classes = ("btn-simple", "btn-full-snapshot")
    data_type_singular = _(" ")
    data_type_plural = _(" ")
  
        
    def action(self, request, obj_id):
        try:
            workload_id = obj_id
            workloadmgr.workload_snapshot(request, workload_id, full=True)
            LOG.debug('Full snapshot of workload %s scheduled successfully' % workload_id)
        except:
            msg = _('Failed to take full snapshot of workload %s') % workload_id
            LOG.info(msg)
            redirect = reverse("horizon:project:workloads:index")
            exceptions.handle(request, msg, redirect=redirect)
            
            
class WorkloadSnapshot(tables.BatchAction):
    name = "Snapshot"
    verbose_name = _("Snapshot")
    action_present = _("Snapshot")
    action_past = _("Scheduled execution of")
    classes = ("btn-simple", "btn-snapshot")
    data_type_singular = _(" ")
    data_type_plural = _(" ")
        
    def action(self, request, obj_id):
        try:
            workload_id = obj_id
            workloadmgr.workload_snapshot(request, workload_id, full=False)
            LOG.debug('Snapshot of workload %s scheduled successfully' % workload_id)
        except:
            msg = _('Failed to take snapshot of workload %s') % workload_id
            LOG.info(msg)
            redirect = reverse("horizon:project:workloads:index")
            exceptions.handle(request, msg, redirect=redirect) 
            
class WorkloadUnlock(tables.BatchAction):
    name = "Unlock"
    verbose_name = _("Unlock")
    action_present = _("Unlock")
    action_past = _("Unlocked")
    classes = ("btn-simple", "btn-unlock")
    data_type_singular = _(" ")
    data_type_plural = _(" ")
        
    def action(self, request, obj_id):
        try:
            workload_id = obj_id
            workloadmgr.workload_unlock(request, workload_id)
            LOG.debug('Workload %s unlocked successfully' % workload_id)
        except:
            msg = _('Failed to unlock workload %s') % workload_id
            LOG.info(msg)
            redirect = reverse("horizon:project:workloads:index")
            exceptions.handle(request, msg, redirect=redirect)                                  
            
class DeleteWorkload(tables.DeleteAction):
    data_type_singular = _("Workload")
    data_type_plural = _("Workloads")

    def delete(self, request, workload_id):
        try:
            workloadmgr.workload_delete(request, workload_id)
            LOG.debug('Deleted workload %s successfully' % workload_id)
        except:
            msg = _('Failed to delete workload %s') % workload_id
            LOG.info(msg)
            redirect = reverse("horizon:project:workloads:index")
            exceptions.handle(request, msg, redirect=redirect)
            
class UpdateRow(tables.Row):
    ajax = True

    def get_data(self, request, workload_id):
        workload = workloadmgr.workload_get(request, workload_id)
        return workload

class CreateWorkload(tables.LinkAction):
    name = "create"
    verbose_name = _("Create Workload")
    url = "horizon:project:workloads:create"
    classes = ("ajax-modal", "btn-create")

class WorkloadsTable(tables.DataTable):
    name = tables.Column( "name", verbose_name=_("Name"))
    id = tables.Column("id", verbose_name=_("ID"), link='horizon:project:workloads:detail')
    status = tables.Column("status", verbose_name=_("Status"))      
    class Meta:
        name = "workloads"
        verbose_name = _("Workloads")
        row_class = UpdateRow
        table_actions = (CreateWorkload, DeleteWorkload)
        row_actions = (WorkloadSnapshot, WorkloadSnapshotFull, WorkloadUnlock, DeleteWorkload,)
        

class WorkloadTypesTable(tables.DataTable):
    name = tables.Column( "name", verbose_name=_("Name"))
    id = tables.Column("id", verbose_name=_("ID"))
     
    class Meta:
        name = "workload_types"
        verbose_name = _("WorkloadTypes")
        row_class = UpdateRow
        table_actions = ()
        row_actions = ()
                
