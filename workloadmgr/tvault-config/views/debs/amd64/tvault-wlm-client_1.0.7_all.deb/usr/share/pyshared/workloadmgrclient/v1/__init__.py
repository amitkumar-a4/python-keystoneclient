# Copyright (c) 2014 TrilioData, Inc.
# All Rights Reserved.

from workloadmgrclient.v1.client import Client     # noqa
