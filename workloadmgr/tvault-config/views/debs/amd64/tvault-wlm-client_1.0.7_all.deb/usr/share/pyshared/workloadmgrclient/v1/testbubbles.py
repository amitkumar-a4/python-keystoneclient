# Copyright (c) 2014 TrilioData, Inc.
# All Rights Reserved.

"""
Testbubbles interface (1.1 extension).
"""

import six
try:
    from urllib import urlencode
except ImportError:
    from urllib.parse import urlencode
    
from workloadmgrclient import base


class Testbubble(base.Resource):
    """A snapshot testbubble either test or production"""
    def __repr__(self):
        return "<Testbubble: %s>" % self.id

    def delete(self):
        """Delete this testbubble."""
        return self.manager.delete(self)

class TestbubblesManager(base.ManagerWithFind):
    """Manage :class:`Testbubble` resources."""
    resource_class = Testbubble


    def get(self, testbubble_id):
        """Show details of a snapshot testbubble.

        :param testbubble_id: The ID of the snapshot testbubble to display.
        :rtype: :class:`Testbubble`
        """
        return self._get("/testbubbles/%s" % testbubble_id, "testbubble")

    def list(self, detailed=True, search_opts=None):
        """Get a list of all snapshot testbubbles

        :rtype: list of :class:`Testbubble`
        """
        if search_opts is None:
            search_opts = {}   
            
        qparams = {}

        for opt, val in six.iteritems(search_opts):
            if val:
                qparams[opt] = val

        query_string = "?%s" % urlencode(qparams) if qparams else ""

        detail = ""
        if detailed:
            detail = "/detail"
        
        return self._list("/testbubbles%s%s" % (detail, query_string),
                          "testbubbles")
                          
    def delete(self, testbubble_id):
        """Delete a snapshot testbubble.

        :param testbubble_id: The :class:`Testbubble` to delete.
        """
        self._delete("/testbubbles/%s" % base.getid(testbubble_id))

